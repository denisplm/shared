# Instruções para o GitHub Copilot — PowerBI Robot

## Visão geral

PowerBI Robot é um app desktop para **Windows 11 x64** que extrai indicadores de dashboards Power BI por scraping e grava **um CSV por fluxo**.

- **Stack**: Electron 33 + React 18 + TypeScript (strict) + Playwright (`playwright-core`) controlando o Edge ou o Chrome instalado, build com electron-vite e electron-builder.
- **Distribuição**: `npm run dist:win` gera o **instalador** `dist/PowerBI Robot-Setup-x.y.z.exe` (NSIS, por usuário, sem administrador, pasta de instalação escolhível) e o **`.zip`** da pasta do app (`dist/PowerBI Robot-x.y.z-win-x64.zip`). **Não** use o alvo `portable`: ele roda a partir do `%TEMP%`, bloqueado pela política da rede corporativa. Não gere builds para macOS/Linux.
- **Idioma**: UI, mensagens, logs, comentários e documentação em **português (pt-BR)**. Identificadores de código em inglês ou português, seguindo o arquivo ao redor.

## Comandos

| Comando | Uso |
| --- | --- |
| `npm run dev` | Roda o app em desenvolvimento |
| `npm run typecheck` | Verificação de tipos (main/preload e renderer) — rode após qualquer alteração |
| `npm run build` | Build do electron-vite em `out/` |
| `npm run dist:win` | Gera o instalador e o `.zip` do app em `dist/` |
| `npm run dist:dir` | Gera a versão Windows descompactada em `dist/win-unpacked/` (para inspeção) |

**Electron offline**: o download do Electron no `npm install` está bloqueado (`allowScripts` no `package.json`). `dev`, `build` e `dist:*` rodam via `scripts/electron-local.mjs`, que usa a release descompactada indicada em `electron.local.json` na raiz (`path`) ou na variável `ELECTRON_DIST_PATH`; se a pasta não existir e houver Electron em `node_modules`, usa esse. O NSIS também é baixado manualmente: `nsisPath` (nsis-3.0.4.1) e `nsisResourcesPath` (nsis-resources-3.4.1) em `electron.local.json`; o script define `ELECTRON_BUILDER_NSIS_DIR` e copia os plugins para `node_modules/.cache/electron-builder` (`ELECTRON_BUILDER_CACHE`). Assim o build não baixa nada do GitHub — não adicione alvos ou dependências que exijam outros downloads. Não chame `electron-vite`/`electron-builder` diretamente nos scripts, não remova esse bloqueio e, ao atualizar o Electron, atualize também a versão em `allowScripts`.

## Estrutura

```
src/
  shared/          Tipos e catálogo compartilhados entre main e renderer
    flows.ts       FLOW_CATALOG: id, nome e coluna de valor de cada fluxo (fonte única)
    period.ts      Filtro Mês anterior/Mês atual: resolvePeriod() → dataInicial, dataFinal, mesAno…
    types.ts       FlowState, AuthState, PublicSettings, RobotApi (contrato IPC)
  main/            Processo principal (Node)
    env.ts         Caminhos em userData (sessão e configurações) — importado primeiro
    index.ts       Janela, handlers IPC, envio de eventos ao renderer
    settings.ts    Configurações em JSON no userData (não guarda e-mail nem senha)
    browser.ts     Abre o Edge/Chrome instalado (launchBrowser)
    auth.ts        Login manual (botão Entrar), sessão (storageState) e validação
    human.ts       Digitação/cliques humanos e bloqueio de fill()
    csv.ts         Gravação do CSV de cada fluxo
    runner.ts      Ciclo de vida dos fluxos (play/stop, progresso, logs, CSV)
    flows/
      types.ts     FlowDefinition e FlowContext
      helpers.ts   Utilitários de Power BI (waitForReport, setDateRangeSlicer, selectSlicerOption,
                   exportVisualData, typeInSlicerSearch, toMesAno, parseNumeroBR…)
      index.ts     Registro dos coletores
      coletores/   Um arquivo por fluxo com a função collect()
  preload/         Ponte contextBridge → window.robot (RobotApi)
  renderer/        UI React (App, FlowCard, SettingsPanel, styles.css)
```

## Regras obrigatórias

### 1. Um CSV por fluxo
- Cada fluxo grava **exatamente um arquivo**: `<pasta configurada>/<id-do-fluxo>.csv`, sobrescrito a cada coleta bem-sucedida. Nunca crie nomes com data/hora nem arquivos extras por fluxo.
- Colunas, nesta ordem: `nome_tribo`, `mes_ano_competencia` (formato `MM/AAAA`) e **uma** coluna de valor definida em `FLOW_CATALOG` (`total`, `total_dias` ou `total_percentual`).
- Grave sempre por `writeFlowCsv` (gravação atômica, com BOM UTF-8 e separador configurável). Não escreva CSV diretamente com `fs`.
- O CSV deve existir mesmo vazio. Em erro ou interrupção, `guaranteeCsv` cria só o cabeçalho se o arquivo ainda não existir — **nunca apague dados de uma coleta anterior**.

### 2. Digitação humana
- Em qualquer campo digitável dos fluxos coletáveis, use `human.type(locator, texto)` / `humanType`. **Nunca** use `locator.fill()`, `page.fill()` nem `keyboard.insertText()`.
- Para cliques, prefira `human.click(locator)`; para teclas, `human.press(locator, 'Enter')`; entre ações, `human.pause()`.
- `enforceHumanTyping` redireciona `fill()` para `humanType` em toda página aberta, mas o código novo deve chamar as funções humanas explicitamente.

### 3. Autenticação e sessão
- O app **não guarda nem digita e-mail/senha**. Não adicione campos de credenciais. O login acontece só pelo botão **Entrar**: `login()` abre o Power BI num navegador visível (`headless: false`), o usuário digita as credenciais e aprova o MFA, e o app apenas aguarda o Power BI carregar para salvar a sessão.
- A sessão é salva com `storageState` em `userData/session/storage-state.json` e reaproveitada por `sessionContextOptions()`.
- Status exibido: `checking` (Verificando sessão…), `valid` (Autenticado), `invalid` (Não autenticado), `authenticating` (janela de login aberta).
- A sessão é validada ao abrir o app e a cada 30 minutos (`startSessionMonitor` / `checkSession`) e no início de cada fluxo (`navigateWithSession`). Se expirou, o status vira **Não autenticado** e o fluxo termina com erro pedindo para clicar em Entrar — o fluxo **não** abre a janela de login sozinho.
- `login()` é protegido contra concorrência (uma janela de login por vez). Não chame `doLogin()` diretamente.

### 4. Playwright e navegador
- Use `playwright-core` (não `playwright`), que não baixa navegadores. O app **nunca baixa navegador**: usa o **Edge** (`channel: 'msedge'`, padrão no Windows) ou o **Chrome** (`channel: 'chrome'`) instalado, conforme a configuração `browserChannel`. Não reintroduza Chromium baixado (`playwright install`) — a rede corporativa bloqueia.
- Abra navegadores sempre por `launchBrowser()`; ele usa o canal configurado, traduz "navegador não encontrado" numa mensagem em português, aplica a digitação humana e, com a configuração `startMaximized`, abre as janelas visíveis maximizadas (viewport `null`, a página ocupa a janela).
- Fora de `browser.ts`, importe de `playwright-core` apenas tipos (`import type`).
- `playwright-core` precisa continuar em `asarUnpack` no `electron-builder.yml`.

### 5. Interface
- **Topo**: status da sessão (Verificando sessão… / Autenticado / Não autenticado), botão **Entrar** (só quando não autenticado), ícones de pasta dos CSVs, **Configurações** e **Sair** (só com sessão salva; pede confirmação e apaga a sessão).
- **Card do fluxo**: nome, status, URL do dashboard, filtro de período com o intervalo de datas, progresso, play/stop, download do CSV e logs. Não exiba a coluna de valor (`total`, `total_dias`, `total_percentual`) no card.
- **Configurações**: pasta dos CSVs, separador do CSV, mostrar o navegador durante a coleta, iniciar o navegador maximizado e navegador (Edge ou Chrome instalado). Não coloque login, credenciais nem "encerrar sessão" nas configurações.

### 6. Arquitetura Electron
- O renderer não acessa Node: toda funcionalidade nova passa por `RobotApi` (`src/shared/types.ts`) → `preload/index.ts` → `ipcMain.handle` em `main/index.ts`. Mantenha os três sincronizados.
- Atualizações de estado vão do main para o renderer por eventos (`flow:update`, `auth:update`); o renderer não faz polling.
- Mantenha `contextIsolation: true`.

## Como implementar um fluxo coletável

1. Edite `src/main/flows/coletores/<id>.ts`. Nome e coluna de valor vêm de `src/shared/flows.ts`; não os duplique no coletor.
2. `collect(ctx)` recebe a página **já autenticada e aberta na URL do fluxo** e retorna `IndicatorRow[]`:

```ts
export const bacen: FlowDefinition = {
  id: 'bacen',
  async collect({ page, periodo, signal, progress, log, human }) {
    const dataInicial = periodo.dataInicial // ex.: 01/09/2026
    const dataFinal = periodo.dataFinal // ex.: 30/09/2026
    const competencia = periodo.mesAno // ex.: 09/2026

    progress(40, 'Aguardando o relatório carregar…')
    await waitForReport(page)
    throwIfAborted(signal)

    await setDateRangeSlicer(page, 'Data', dataInicial, dataFinal)
    await human.type(page.getByPlaceholder('Pesquisar'), 'Tribo X')
    // … ler visuais ou exportar dados com exportVisualData() …

    return [{ nome_tribo: 'Tribo X', mes_ano_competencia: competencia, valor: parseNumeroBR('98,5%') }]
  }
}
```

3. **Filtro de período**: todo card tem "Mês anterior / Mês atual". O coletor recebe `periodo` (`Competencia` de `src/shared/period.ts`), calculado no início da coleta, e cada coletor já declara `dataInicial`, `dataFinal` (DD/MM/AAAA) e `competencia` (MM/AAAA). `dataFinal` é sempre o último dia real do mês (28, 29, 30 ou 31) — nunca fixe o dia final nem calcule datas no coletor; use `resolvePeriod`. Aplique o período no relatório (ex.: `setDateRangeSlicer(page, 'Data', dataInicial, dataFinal)`) e use `competencia` em `mes_ano_competencia`.
4. Chame `throwIfAborted(signal)` entre etapas longas para o botão **Parar** funcionar.
5. Informe o progresso com `progress(percent, mensagem)` (o runner limita a 30–95%) e registre eventos com `log()`.
6. Não grave o CSV nem feche o navegador no coletor: o runner faz isso.
7. Prefira seletores estáveis (`getByRole`, `aria-label`, textos visíveis) e aguarde elementos em vez de usar tempos fixos.
8. Para um **novo** fluxo: adicione-o em `FLOW_CATALOG`, crie o coletor em `coletores/` e registre-o em `flows/index.ts`.

## Estilo de código

- TypeScript strict, sem `any`. Tipos compartilhados ficam em `src/shared/`.
- Funções pequenas, `async/await`, sem dependências novas sem necessidade.
- Erros exibidos ao usuário devem ser mensagens claras em português (ex.: `"Feche o arquivo no Excel e tente novamente."`).
- UI limpa e intuitiva: reutilize as classes e tokens de cor de `styles.css` (`--primary`, `--ok`, `--err`…), e use os componentes de ícone de `Icons.tsx`.
- Não adicione botão "Executar todos": cada fluxo é iniciado e parado individualmente pelo seu play/stop.
