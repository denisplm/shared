// Executa electron-vite / electron-builder sem baixar nada da internet, usando
// arquivos baixados manualmente e indicados em electron.local.json (raiz do projeto):
//
//   {
//     "path": "C:/electron/electron-v33.2.1-win32-x64",       release do Electron descompactada
//     "nsisPath": "C:/electron/nsis-3.0.4.1",                 nsis-3.0.4.1.7z descompactado
//     "nsisResourcesPath": "C:/electron/nsis-resources-3.4.1" nsis-resources-3.4.1.7z descompactado
//   }
//
// "path" também pode vir da variável de ambiente ELECTRON_DIST_PATH. Sem "path" (ou se
// a pasta não existir nesta máquina), usa o Electron de node_modules/electron/dist, se
// existir. Sem os caminhos do NSIS, o electron-builder tenta baixá-lo do GitHub.
//
// Uso: node scripts/electron-local.mjs <electron-vite|electron-builder> [argumentos…]

import { spawn } from 'node:child_process'
import { cpSync, existsSync, readdirSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(join(root, 'package.json'))
const [tool, ...args] = process.argv.slice(2)
const electronVersion = require('electron/package.json').version
// O build do electron-vite só compila o código; não executa o Electron.
const runsElectron = !(tool === 'electron-vite' && args[0] === 'build')

// Versões que o electron-builder 25 espera (ver app-builder-lib/out/targets/nsis).
const NSIS = 'nsis-3.0.4.1'
const NSIS_RESOURCES = 'nsis-resources-3.4.1'

const CLIS = {
  'electron-vite': 'electron-vite/bin/electron-vite.js',
  'electron-builder': 'electron-builder/cli.js'
}

function fail(message) {
  console.error(`\n[electron-local] ${message}\n`)
  process.exit(1)
}

if (!CLIS[tool]) fail(`Ferramenta desconhecida: "${tool}". Use electron-vite ou electron-builder.`)

function loadConfig() {
  const file = join(root, 'electron.local.json')
  if (!existsSync(file)) return {}
  try {
    return JSON.parse(readFileSync(file, 'utf-8'))
  } catch (err) {
    fail(`electron.local.json inválido: ${err.message}\nNo Windows use barras normais ou duplas: "C:/electron/…" ou "C:\\\\electron\\\\…".`)
  }
}

/** Executável do Electron dentro da release descompactada, conforme o sistema. */
function executableIn(dist) {
  if (process.platform === 'win32') return join(dist, 'electron.exe')
  if (process.platform === 'darwin') return join(dist, 'Electron.app', 'Contents', 'MacOS', 'Electron')
  return join(dist, 'electron')
}

/**
 * Pasta descompactada que contém `marker`. Aceita também uma subpasta a mais,
 * comum ao descompactar no Windows (ex.: nsis-3.0.4.1/nsis-3.0.4.1/…).
 */
function findExtracted(dir, marker, key, archive) {
  if (!existsSync(dir)) fail(`Pasta não encontrada: ${dir}\nAjuste "${key}" em electron.local.json (descompacte ${archive} nela).`)
  if (existsSync(join(dir, marker))) return dir
  const nested = readdirSync(dir, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => join(dir, d.name))
  const found = nested.find((d) => existsSync(join(d, marker)))
  if (!found) fail(`"${marker}" não encontrado em ${dir}.\nVerifique se "${key}" aponta para ${archive} descompactado.`)
  return found
}

const config = loadConfig()
const env = { ...process.env, ELECTRON_SKIP_BINARY_DOWNLOAD: '1' }

// --- Electron ----------------------------------------------------------------
const hasModuleElectron = existsSync(join(root, 'node_modules', 'electron', 'path.txt'))
const distPath = process.env.ELECTRON_DIST_PATH || config.path
let dist = distPath ? resolve(root, distPath) : null

if (dist && !existsSync(dist)) {
  // Ex.: o caminho de electron.local.json é de outra máquina. Se o Electron já
  // estiver em node_modules, usa-o; senão, o caminho precisa ser corrigido.
  if (!hasModuleElectron) fail(`Pasta do Electron não encontrada: ${dist}\nAjuste o "path" em electron.local.json.`)
  console.warn(`[electron-local] Pasta ${dist} não encontrada; usando o Electron de node_modules.`)
  dist = null
}

if (dist) {
  const versionFile = join(dist, 'version')
  const found = existsSync(versionFile) ? readFileSync(versionFile, 'utf-8').trim().replace(/^v/, '') : null
  if (found && found !== electronVersion) {
    fail(`A release em ${dist} é a versão ${found}, mas o projeto usa a ${electronVersion}.\nBaixe electron-v${electronVersion}-<sistema>-x64.zip.`)
  }

  if (tool === 'electron-builder') {
    // A release precisa ser do sistema de destino do .exe (win32-x64).
    args.push(`--config.electronDist=${dist}`)
    console.log(`[electron-local] Usando Electron local: ${dist}`)
  } else if (runsElectron) {
    const exe = executableIn(dist)
    if (!existsSync(exe)) fail(`Executável do Electron não encontrado em ${exe}.\nVerifique se a pasta é a release descompactada.`)
    env.ELECTRON_EXEC_PATH = exe
    env.ELECTRON_OVERRIDE_DIST_PATH = dist
    console.log(`[electron-local] Usando Electron local: ${dist}`)
  }
} else if (runsElectron && !hasModuleElectron) {
  // Sem caminho configurado e sem Electron em node_modules.
  fail(
    `Electron não configurado. Baixe a release electron-v${electronVersion}-win32-x64.zip, descompacte e informe\n` +
      `a pasta em electron.local.json, na raiz do projeto:\n  { "path": "C:/electron/electron-v${electronVersion}-win32-x64" }\n` +
      '(ou defina a variável de ambiente ELECTRON_DIST_PATH)'
  )
}

// --- NSIS (gera o instalador) ------------------------------------------------
if (tool === 'electron-builder') {
  if (config.nsisPath && config.nsisResourcesPath) {
    const nsis = findExtracted(resolve(root, config.nsisPath), 'makensis.exe', 'nsisPath', `${NSIS}.7z`)
    const resources = findExtracted(resolve(root, config.nsisResourcesPath), 'plugins', 'nsisResourcesPath', `${NSIS_RESOURCES}.7z`)
    env.ELECTRON_BUILDER_NSIS_DIR = nsis
    // Os plugins do NSIS só são lidos do cache do electron-builder
    // (<cache>/nsis/nsis-resources-3.4.1): copia para um cache dentro do projeto.
    const cache = join(root, 'node_modules', '.cache', 'electron-builder')
    const cachedResources = join(cache, 'nsis', NSIS_RESOURCES)
    if (!existsSync(join(cachedResources, 'plugins'))) cpSync(resources, cachedResources, { recursive: true })
    env.ELECTRON_BUILDER_CACHE = cache
    console.log(`[electron-local] Usando NSIS local: ${nsis}`)
  } else if (config.nsisPath || config.nsisResourcesPath) {
    fail('Informe "nsisPath" e "nsisResourcesPath" em electron.local.json (os dois são necessários).')
  } else {
    console.warn('[electron-local] NSIS não configurado em electron.local.json; o electron-builder tentará baixá-lo do GitHub.')
  }
}

const child = spawn(process.execPath, [join(root, 'node_modules', CLIS[tool]), ...args], { cwd: root, env, stdio: 'inherit' })
child.on('exit', (code, signal) => process.exit(signal ? 1 : (code ?? 1)))
