// Executa electron-vite / electron-builder usando um Electron baixado manualmente
// (release do GitHub descompactada), sem baixar nada da internet.
//
// O caminho vem de, nesta ordem:
//   1. variável de ambiente ELECTRON_DIST_PATH
//   2. electron.local.json na raiz do projeto: { "path": "C:/electron/electron-v33.2.1-win32-x64" }
// Sem caminho configurado (ou se a pasta indicada não existir nesta máquina), usa o
// Electron de node_modules/electron/dist, se existir.
//
// Uso: node scripts/electron-local.mjs <electron-vite|electron-builder> [argumentos…]

import { spawn } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(join(root, 'package.json'))
const [tool, ...args] = process.argv.slice(2)
const electronVersion = require('electron/package.json').version
// O build do electron-vite só compila o código; não executa o Electron.
const runsElectron = !(tool === 'electron-vite' && args[0] === 'build')

const CLIS = {
  'electron-vite': 'electron-vite/bin/electron-vite.js',
  'electron-builder': 'electron-builder/cli.js'
}

function fail(message) {
  console.error(`\n[electron-local] ${message}\n`)
  process.exit(1)
}

if (!CLIS[tool]) fail(`Ferramenta desconhecida: "${tool}". Use electron-vite ou electron-builder.`)

function configuredDistPath() {
  if (process.env.ELECTRON_DIST_PATH) return process.env.ELECTRON_DIST_PATH
  const file = join(root, 'electron.local.json')
  if (!existsSync(file)) return null
  try {
    return JSON.parse(readFileSync(file, 'utf-8')).path || null
  } catch (err) {
    fail(`electron.local.json inválido: ${err.message}\nNo Windows use barras normais ou duplas: "C:/electron/…" ou "C:\\\\electron\\\\…".`)
  }
}

/** Executável do Electron dentro da release descompactada, conforme o sistema. */
function executableIn(dist) {
  if (process.platform === 'win32') return join(dist, 'electron.exe')
  if (process.platform === 'darwin') return join(dist, 'Electron.app', 'Contents', 'MacOS', 'Electron')
  return join(dist, 'electron')
}

const env = { ...process.env, ELECTRON_SKIP_BINARY_DOWNLOAD: '1' }
const distPath = configuredDistPath()

const hasModuleElectron = existsSync(join(root, 'node_modules', 'electron', 'path.txt'))
let dist = distPath ? resolve(root, distPath) : null

if (dist && !existsSync(dist)) {
  // Ex.: o caminho de electron.local.json é de outra máquina. Se o Electron já
  // estiver em node_modules, usa-o; senão, o caminho precisa ser corrigido.
  if (!hasModuleElectron) fail(`Pasta do Electron não encontrada: ${dist}\nAjuste o "path" em electron.local.json.`)
  console.warn(`[electron-local] Pasta ${dist} não encontrada; usando o Electron de node_modules.`)
  dist = null
}

if (dist) {
  const versionFile = join(dist, 'version')
  const found = existsSync(versionFile) ? readFileSync(versionFile, 'utf-8').trim().replace(/^v/, '') : null
  if (found && found !== electronVersion) {
    fail(`A release em ${dist} é a versão ${found}, mas o projeto usa a ${electronVersion}.\nBaixe electron-v${electronVersion}-<sistema>-x64.zip.`)
  }

  if (tool === 'electron-builder') {
    // A release precisa ser do sistema de destino do .exe (win32-x64).
    args.push(`--config.electronDist=${dist}`)
    console.log(`[electron-local] Usando Electron local: ${dist}`)
  } else if (runsElectron) {
    const exe = executableIn(dist)
    if (!existsSync(exe)) fail(`Executável do Electron não encontrado em ${exe}.\nVerifique se a pasta é a release descompactada.`)
    env.ELECTRON_EXEC_PATH = exe
    env.ELECTRON_OVERRIDE_DIST_PATH = dist
    console.log(`[electron-local] Usando Electron local: ${dist}`)
  }
} else if (runsElectron && !hasModuleElectron) {
  // Sem caminho configurado e sem Electron em node_modules.
  fail(
    `Electron não configurado. Baixe a release electron-v${electronVersion}-win32-x64.zip, descompacte e informe\n` +
      `a pasta em electron.local.json, na raiz do projeto:\n  { "path": "C:/electron/electron-v${electronVersion}-win32-x64" }\n` +
      '(ou defina a variável de ambiente ELECTRON_DIST_PATH)'
  )
}

const child = spawn(process.execPath, [join(root, 'node_modules', CLIS[tool]), ...args], { cwd: root, env, stdio: 'inherit' })
child.on('exit', (code, signal) => process.exit(signal ? 1 : (code ?? 1)))
