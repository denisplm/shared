// Gera build/icon.png (512 px) e build/icon.ico (16–256 px) a partir de build/icon.svg,
// renderizando o SVG no Edge/Chrome instalado. Rode após alterar o desenho:
//   npm run icons
// Os arquivos gerados ficam no projeto: o build não precisa rodar este script.

import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { chromium } from 'playwright-core'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const build = join(root, 'build')
const svg = readFileSync(join(build, 'icon.svg'), 'utf-8')
const ICO_SIZES = [16, 24, 32, 48, 64, 128, 256]

async function launch() {
  for (const channel of ['msedge', 'chrome']) {
    try {
      return await chromium.launch({ channel })
    } catch {
      // tenta o próximo navegador instalado
    }
  }
  throw new Error('Nenhum navegador encontrado (Edge ou Chrome) para renderizar o ícone.')
}

async function render(page, size) {
  const src = `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`
  const dataUrl = await page.evaluate(
    async ({ src, size }) => {
      const img = new Image()
      img.src = src
      await img.decode()
      const canvas = document.createElement('canvas')
      canvas.width = canvas.height = size
      const ctx = canvas.getContext('2d')
      ctx.imageSmoothingQuality = 'high'
      ctx.drawImage(img, 0, 0, size, size)
      return canvas.toDataURL('image/png')
    },
    { src, size }
  )
  return Buffer.from(dataUrl.split(',')[1], 'base64')
}

/** Monta um .ico com as imagens em PNG (formato aceito pelo Windows desde o Vista). */
function buildIco(images) {
  const header = Buffer.alloc(6)
  header.writeUInt16LE(0, 0) // reservado
  header.writeUInt16LE(1, 2) // tipo: ícone
  header.writeUInt16LE(images.length, 4)
  const entries = []
  let offset = 6 + 16 * images.length
  for (const { size, png } of images) {
    const entry = Buffer.alloc(16)
    entry.writeUInt8(size >= 256 ? 0 : size, 0) // largura (0 = 256)
    entry.writeUInt8(size >= 256 ? 0 : size, 1) // altura
    entry.writeUInt8(0, 2) // paleta
    entry.writeUInt8(0, 3) // reservado
    entry.writeUInt16LE(1, 4) // planos
    entry.writeUInt16LE(32, 6) // bits por pixel
    entry.writeUInt32LE(png.length, 8)
    entry.writeUInt32LE(offset, 12)
    entries.push(entry)
    offset += png.length
  }
  return Buffer.concat([header, ...entries, ...images.map((i) => i.png)])
}

const browser = await launch()
try {
  const page = await browser.newPage()
  writeFileSync(join(build, 'icon.png'), await render(page, 512))
  const images = []
  for (const size of ICO_SIZES) images.push({ size, png: await render(page, size) })
  writeFileSync(join(build, 'icon.ico'), buildIco(images))
  console.log(`Gerados build/icon.png (512 px) e build/icon.ico (${ICO_SIZES.join(', ')} px).`)
} finally {
  await browser.close()
}
