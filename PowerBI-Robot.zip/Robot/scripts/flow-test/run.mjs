// npm run flow -- <fluxo> [opções]
// Compila scripts/flow-test/main.ts (com o código do app) trocando o módulo
// "electron" por um stub, e executa no Node — sem abrir o app.

import { spawn } from 'node:child_process'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { build } from 'esbuild'

const here = dirname(fileURLToPath(import.meta.url))
const root = resolve(here, '..', '..')
const outfile = join(root, 'node_modules', '.cache', 'flow-test', 'main.cjs')

await build({
  entryPoints: [join(here, 'main.ts')],
  outfile,
  bundle: true,
  platform: 'node',
  format: 'cjs',
  target: 'node20',
  sourcemap: 'inline',
  logLevel: 'warning',
  external: ['playwright-core'],
  alias: {
    electron: join(here, 'electron-stub.cjs'),
    '@shared': join(root, 'src', 'shared')
  }
})

// --enable-source-maps: erros apontam para as linhas dos arquivos .ts originais.
const child = spawn(process.execPath, ['--enable-source-maps', outfile, ...process.argv.slice(2)], {
  cwd: root,
  stdio: 'inherit'
})
child.on('exit', (code, signal) => process.exit(signal ? 1 : (code ?? 1)))
