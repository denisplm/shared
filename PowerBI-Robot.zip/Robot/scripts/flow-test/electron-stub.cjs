// Substitui o módulo "electron" quando um fluxo roda fora do app (npm run flow).
// Usa a mesma pasta de dados do app: configurações (URLs, período, navegador,
// tempo de espera) e a sessão do Power BI são compartilhadas.

const { homedir } = require('os')
const { join } = require('path')

function appDataDir() {
  if (process.platform === 'win32') return process.env.APPDATA || join(homedir(), 'AppData', 'Roaming')
  if (process.platform === 'darwin') return join(homedir(), 'Library', 'Application Support')
  return process.env.XDG_CONFIG_HOME || join(homedir(), '.config')
}

const userData = process.env.FLOW_TEST_USER_DATA || join(appDataDir(), 'PowerBI Robot')

const paths = {
  userData,
  appData: appDataDir(),
  documents: join(homedir(), 'Documents'),
  home: homedir()
}

module.exports = {
  app: {
    getPath: (name) => paths[name] ?? join(userData, name),
    getName: () => 'PowerBI Robot',
    isPackaged: false
  },
  // Usado para maximizar a janela no macOS (no Windows basta --start-maximized).
  screen: {
    getPrimaryDisplay: () => ({ workArea: { x: 0, y: 0, width: 1920, height: 1080 } })
  }
}
