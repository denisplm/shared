// Executa um fluxo coletável fora do app, para desenvolver e depurar o coletor.
// Usa exatamente o mesmo código do app (coletor, sessão, digitação humana, período
// e gravação do CSV). Rode com: npm run flow -- <fluxo> [opções]  (ver --help)

import { appendFileSync, mkdirSync, writeFileSync } from 'fs'
import { join, resolve } from 'path'
import { createInterface } from 'node:readline/promises'
import type { Browser, BrowserContext, Page } from 'playwright-core'
import { FLOW_CATALOG } from '@shared/flows'
import { DEFAULT_PERIOD, resolvePeriod } from '@shared/period'
import type { PeriodFilter } from '@shared/types'
import { login, navigateWithSession, saveSession, sessionContextOptions } from '../../src/main/auth'
import { launchBrowser } from '../../src/main/browser'
import { writeFlowCsv, type IndicatorRow } from '../../src/main/csv'
import { SESSION_FILE, SETTINGS_FILE } from '../../src/main/env'
import { getCollector } from '../../src/main/flows'
import type { FlowContext } from '../../src/main/flows/types'
import { humanClick, humanPress, humanType, pause } from '../../src/main/human'
import { getFlowSettings, getSettings } from '../../src/main/settings'

const HELP = `
Uso: npm run flow -- <fluxo> [opções]

Fluxos: ${FLOW_CATALOG.map((f) => f.id).join(', ')}

Opções:
  --url <url>          URL do relatório (padrão: a URL salva no card do app)
  --periodo <p>        mes_anterior | mes_atual (padrão: o período salvo no card)
  --headless           Navegador oculto (padrão: visível)
  --pause              Abre o Playwright Inspector antes do coletor (passo a passo)
  --trace              Grava trace.zip (ver depois com: npm run flow:trace -- <caminho>)
  --keep-open          Mantém o navegador aberto no fim, até apertar Enter
  --sem-sessao         Abre a URL direto, sem validar a sessão do Power BI (para
                       depurar contra uma cópia salva do relatório, ex.: erro.html)
  --list               Lista os fluxos e as URLs salvas no app
  --help               Mostra esta ajuda

Saída em test-output/<fluxo>/<data-hora>/: rows.json, <fluxo>.csv, log.txt
(e erro.png / erro.html se falhar).
`

interface Options {
  flowId?: string
  url?: string
  periodo?: PeriodFilter
  headless: boolean
  pause: boolean
  trace: boolean
  keepOpen: boolean
  noSession: boolean
  list: boolean
  help: boolean
}

function parseArgs(argv: string[]): Options {
  const opts: Options = {
    headless: false,
    pause: false,
    trace: false,
    keepOpen: false,
    noSession: false,
    list: false,
    help: false
  }
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]
    const value = (): string => {
      const next = argv[++i]
      if (!next || next.startsWith('--')) throw new Error(`Informe um valor para ${arg}.`)
      return next
    }
    if (arg === '--url') opts.url = value()
    else if (arg === '--periodo') {
      const p = value()
      if (p !== 'mes_anterior' && p !== 'mes_atual') throw new Error('--periodo deve ser mes_anterior ou mes_atual.')
      opts.periodo = p
    } else if (arg === '--headless') opts.headless = true
    else if (arg === '--pause') opts.pause = true
    else if (arg === '--trace') opts.trace = true
    else if (arg === '--keep-open') opts.keepOpen = true
    else if (arg === '--sem-sessao') opts.noSession = true
    else if (arg === '--list') opts.list = true
    else if (arg === '--help' || arg === '-h') opts.help = true
    else if (arg.startsWith('--')) throw new Error(`Opção desconhecida: ${arg}`)
    else opts.flowId = arg
  }
  return opts
}

async function waitEnter(message: string): Promise<void> {
  const rl = createInterface({ input: process.stdin, output: process.stdout })
  await rl.question(`\n${message}`)
  rl.close()
}

function timestamp(): string {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
}

async function main(): Promise<void> {
  const opts = parseArgs(process.argv.slice(2))
  if (opts.help || (!opts.flowId && !opts.list)) {
    console.log(HELP)
    return
  }
  if (opts.list) {
    console.log(`\nConfigurações do app: ${SETTINGS_FILE}\n`)
    for (const f of FLOW_CATALOG) {
      const saved = getFlowSettings(f.id)
      console.log(`${f.enabled ? '●' : '○'} ${f.id.padEnd(22)} ${saved.period ?? DEFAULT_PERIOD}  ${saved.url || '(sem URL)'}`)
    }
    console.log('\n● implementado   ○ não implementado')
    return
  }

  const flowId = opts.flowId!
  const meta = FLOW_CATALOG.find((f) => f.id === flowId)
  const collector = getCollector(flowId)
  if (!meta || !collector) throw new Error(`Fluxo desconhecido: ${flowId}. Use --list para ver os fluxos.`)

  const saved = getFlowSettings(flowId)
  const url = opts.url ?? saved.url
  if (!url) throw new Error(`Sem URL para ${flowId}: informe --url ou salve a URL no card do app.`)
  const periodo = resolvePeriod(opts.periodo ?? saved.period ?? DEFAULT_PERIOD)

  const outDir = resolve('test-output', flowId, timestamp())
  mkdirSync(outDir, { recursive: true })
  const logFile = join(outDir, 'log.txt')
  const log = (message: string, level: 'info' | 'warn' | 'error' = 'info'): void => {
    const line = `${new Date().toLocaleTimeString('pt-BR')} ${level === 'info' ? ' ' : level === 'warn' ? '!' : '✗'} ${message}`
    console.log(line)
    appendFileSync(logFile, line + '\n')
  }

  log(`Fluxo: ${meta.name} (${flowId})${meta.enabled ? '' : ' — marcado como não implementado no app'}`)
  log(`URL: ${url}`)
  log(`Período: ${periodo.label} — ${periodo.dataInicial} a ${periodo.dataFinal} (competência ${periodo.mesAno})`)
  log(`Navegador: ${getSettings().browserChannel}${opts.headless ? ' (oculto)' : ''} | Sessão: ${SESSION_FILE}`)
  log(`Saída: ${outDir}`)

  // Ctrl+C interrompe o coletor como o botão "Parar" do app.
  const controller = new AbortController()
  process.once('SIGINT', () => {
    log('Interrompido (Ctrl+C).', 'warn')
    controller.abort()
  })

  let browser: Browser | null = null
  let context: BrowserContext | null = null
  let page: Page | null = null
  try {
    const open = async (): Promise<Page> => {
      browser = await launchBrowser({ headless: opts.headless })
      context = await browser.newContext(sessionContextOptions())
      if (opts.trace) await context.tracing.start({ screenshots: true, snapshots: true, sources: true })
      return context.newPage()
    }

    page = await open()
    if (opts.noSession) {
      log('Abrindo a URL sem validar a sessão (--sem-sessao)…', 'warn')
      await page.goto(url, { waitUntil: 'domcontentloaded' })
    } else {
      log('Abrindo o relatório com a sessão salva…')
    }
    if (!opts.noSession && !(await navigateWithSession(page, url))) {
      if (opts.headless) throw new Error('Sessão inválida ou expirada. Rode sem --headless para fazer login.')
      log('Sessão inválida ou expirada — faça login e aprove o MFA na janela que vai abrir.', 'warn')
      await browser!.close()
      await login()
      log('Login concluído; sessão salva.')
      page = await open()
      if (!(await navigateWithSession(page, url))) throw new Error('Não foi possível abrir o relatório mesmo após o login.')
    }
    if (!opts.noSession) log('Sessão válida; relatório aberto.')

    if (opts.pause) {
      log('Playwright Inspector aberto: use "Step over"/"Resume" para seguir.')
      await page.pause()
    }

    const started = Date.now()
    const ctx: FlowContext = {
      page,
      url,
      periodo,
      signal: controller.signal,
      progress: (percent, message) => log(`[${String(percent).padStart(3)}%] ${message}`),
      log,
      human: { type: humanType, click: humanClick, press: humanPress, pause }
    }
    const rows: IndicatorRow[] = await collector.collect(ctx)
    log(`Coletor terminou em ${((Date.now() - started) / 1000).toFixed(1)} s com ${rows.length} linha(s).`)

    writeFileSync(join(outDir, 'rows.json'), JSON.stringify(rows, null, 2))
    const csv = writeFlowCsv(outDir, flowId, meta.valueColumn, rows, getSettings().csvDelimiter)
    console.table(rows.map((r) => ({ nome_tribo: r.nome_tribo, mes_ano_competencia: r.mes_ano_competencia, [meta.valueColumn]: r.valor })))
    log(`CSV (formato do app): ${csv}`)
    if (!opts.noSession) await saveSession(page).catch(() => undefined)

    if (opts.keepOpen && !opts.headless) await waitEnter('Navegador aberto para inspeção. Pressione Enter para fechar…')
  } catch (err) {
    const message = err instanceof Error ? (err.stack ?? err.message) : String(err)
    log(message, 'error')
    if (page) {
      await page.screenshot({ path: join(outDir, 'erro.png'), fullPage: true }).catch(() => undefined)
      writeFileSync(join(outDir, 'erro.html'), await page.content().catch(() => ''))
      log(`Print e HTML da página no momento do erro: ${join(outDir, 'erro.png')}`, 'error')
    }
    process.exitCode = 1
    if (!opts.headless && page && !controller.signal.aborted) {
      await waitEnter('Navegador mantido aberto para depuração. Pressione Enter para fechar…')
    }
  } finally {
    const ctxToClose = context as BrowserContext | null
    if (ctxToClose && opts.trace) {
      const tracePath = join(outDir, 'trace.zip')
      await ctxToClose.tracing.stop({ path: tracePath }).catch(() => undefined)
      log(`Trace: ${tracePath}  →  npm run flow:trace -- "${tracePath}"`)
    }
    await (browser as Browser | null)?.close().catch(() => undefined)
  }
}

main().catch((err) => {
  console.error(`\n✗ ${err instanceof Error ? err.message : err}\n`)
  process.exitCode = 1
})
