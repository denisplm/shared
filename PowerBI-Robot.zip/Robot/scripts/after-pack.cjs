// Hook afterPack do electron-builder: grava o ícone (build/icon.ico) e os dados do
// programa (nome, versão) no PowerBI Robot.exe.
//
// O electron-builder faria isso com o rcedit, que ele baixa do GitHub (bloqueado na
// rede corporativa) — por isso signAndEditExecutable está desligado e usamos o
// resedit, biblioteca JavaScript instalada pelo npm.

const { readFileSync, writeFileSync } = require('fs')
const { join } = require('path')
const ResEdit = require('resedit')

const LANG_PT_BR = 1046
const CODEPAGE_UNICODE = 1200

exports.default = async function afterPack(context) {
  if (context.electronPlatformName !== 'win32') return

  const { appInfo } = context.packager
  const { productFilename } = appInfo
  const exePath = join(context.appOutDir, `${productFilename}.exe`)
  const iconPath = join(context.packager.projectDir, 'build', 'icon.ico')

  // ignoreCert: a assinatura original do electron.exe já deixou de valer quando o
  // electron-builder alterou o executável.
  const exe = ResEdit.NtExecutable.from(readFileSync(exePath), { ignoreCert: true })
  const res = ResEdit.NtExecutableResource.from(exe)

  // Ícone: substitui o grupo de ícones existente (o do Electron), mantendo id e idioma.
  const iconFile = ResEdit.Data.IconFile.from(readFileSync(iconPath))
  const [group] = ResEdit.Resource.IconGroupEntry.fromEntries(res.entries)
  ResEdit.Resource.IconGroupEntry.replaceIconsForResource(
    res.entries,
    group ? group.id : 1,
    group ? group.lang : 1033,
    iconFile.icons.map((icon) => icon.data)
  )

  // Detalhes do arquivo (Propriedades → Detalhes no Windows).
  const [versionInfo] = ResEdit.Resource.VersionInfo.fromEntries(res.entries)
  if (versionInfo) {
    const [major, minor, patch] = appInfo.version.split('.').map((n) => parseInt(n, 10) || 0)
    versionInfo.setFileVersion(major, minor, patch, 0)
    versionInfo.setProductVersion(major, minor, patch, 0)
    const strings = {
      ProductName: appInfo.productName,
      FileDescription: appInfo.productName,
      CompanyName: appInfo.companyName || appInfo.productName,
      InternalName: productFilename,
      OriginalFilename: `${productFilename}.exe`,
      FileVersion: appInfo.version,
      ProductVersion: appInfo.version,
      LegalCopyright: ''
    }
    // Atualiza as tabelas de texto existentes (as do Electron) e a de pt-BR.
    const langs = versionInfo.getAllLanguagesForStringValues()
    for (const lang of [...langs, { lang: LANG_PT_BR, codepage: CODEPAGE_UNICODE }]) {
      versionInfo.setStringValues(lang, strings)
    }
    versionInfo.outputToResourceEntries(res.entries)
  }

  res.outputResource(exe)
  writeFileSync(exePath, Buffer.from(exe.generate()))
  console.log(`  • ícone e dados do programa gravados  file=${exePath}`)
}
