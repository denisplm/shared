import { resolve } from 'path'
import { defineConfig, externalizeDepsPlugin } from 'electron-vite'
import react from '@vitejs/plugin-react'

// Electron 40.10.6 traz o Node 24.15.0 e o Chromium 144. O electron-vite 2.3 não
// conhece essa versão, então os alvos de compilação são definidos aqui.
const NODE_TARGET = 'node24'
const CHROME_TARGET = 'chrome144'

export default defineConfig({
  main: {
    plugins: [externalizeDepsPlugin()],
    resolve: { alias: { '@shared': resolve('src/shared') } },
    build: { target: NODE_TARGET }
  },
  preload: {
    plugins: [externalizeDepsPlugin()],
    resolve: { alias: { '@shared': resolve('src/shared') } },
    build: { target: NODE_TARGET }
  },
  renderer: {
    resolve: { alias: { '@shared': resolve('src/shared') } },
    plugins: [react()],
    build: { target: CHROME_TARGET }
  }
})
