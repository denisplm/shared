import type { PeriodFilter } from './types'

export const PERIOD_OPTIONS: { value: PeriodFilter; label: string }[] = [
  { value: 'mes_anterior', label: 'Mês anterior' },
  { value: 'mes_atual', label: 'Mês atual' }
]

export const DEFAULT_PERIOD: PeriodFilter = 'mes_anterior'

/** Competência (mês/ano) resolvida a partir do filtro de período escolhido no card. */
export interface Competencia {
  filtro: PeriodFilter
  /** "Mês anterior" ou "Mês atual". */
  label: string
  /** 1–12 */
  mes: number
  ano: number
  /** Formato MM/AAAA, igual à coluna mes_ano_competencia do CSV. */
  mesAno: string
  /** Primeiro dia do mês, DD/MM/AAAA (ex.: 01/09/2026). */
  dataInicial: string
  /** Último dia do mês, DD/MM/AAAA — respeita meses de 28, 29, 30 ou 31 dias (ex.: 30/09/2026). */
  dataFinal: string
  /** Primeiro dia do mês às 00:00:00 (horário local). */
  inicio: Date
  /** Último dia do mês às 23:59:59.999 (horário local). */
  fim: Date
}

const pad = (n: number): string => String(n).padStart(2, '0')

/** Formata uma data como DD/MM/AAAA. */
export function formatDataBR(d: Date): string {
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`
}

export function resolvePeriod(filtro: PeriodFilter, hoje = new Date()): Competencia {
  const inicio = new Date(hoje.getFullYear(), hoje.getMonth() - (filtro === 'mes_anterior' ? 1 : 0), 1)
  // Dia 0 do mês seguinte = último dia deste mês (28, 29, 30 ou 31).
  const fim = new Date(inicio.getFullYear(), inicio.getMonth() + 1, 0, 23, 59, 59, 999)
  const mes = inicio.getMonth() + 1
  const ano = inicio.getFullYear()
  return {
    filtro,
    label: PERIOD_OPTIONS.find((o) => o.value === filtro)!.label,
    mes,
    ano,
    mesAno: `${pad(mes)}/${ano}`,
    dataInicial: formatDataBR(inicio),
    dataFinal: formatDataBR(fim),
    inicio,
    fim
  }
}
