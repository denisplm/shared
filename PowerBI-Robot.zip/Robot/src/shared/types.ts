/** Coluna de valor do CSV — cada fluxo usa exatamente uma. */
export type ValueColumn = 'total' | 'total_dias' | 'total_percentual'

/** Filtro de período oferecido no card de todos os fluxos. */
export type PeriodFilter = 'mes_anterior' | 'mes_atual'

export interface FlowMeta {
  id: string
  name: string
  valueColumn: ValueColumn
}

export type FlowStatus = 'idle' | 'authenticating' | 'running' | 'success' | 'error' | 'stopped'

export interface FlowLog {
  at: string
  level: 'info' | 'warn' | 'error'
  message: string
}

export interface FlowState extends FlowMeta {
  url: string
  /** Período escolhido no card ("Mês anterior" ou "Mês atual"). */
  period: PeriodFilter
  status: FlowStatus
  /** 0–100 */
  progress: number
  message: string
  logs: FlowLog[]
  /** CSV da última execução bem-sucedida. */
  lastCsvPath?: string
  lastFinishedAt?: string
  lastRowCount?: number
}

export type AuthStatus = 'checking' | 'valid' | 'invalid' | 'authenticating'

export interface AuthState {
  status: AuthStatus
  message: string
}

export interface BrowserSetupState {
  installing: boolean
  message: string
}

export type BrowserChannel = 'chromium' | 'msedge' | 'chrome'

/** Configurações expostas ao renderer. */
export interface PublicSettings {
  outputDir: string
  headless: boolean
  /** Abre as janelas visíveis do navegador maximizadas. */
  startMaximized: boolean
  csvDelimiter: ',' | ';'
  browserChannel: BrowserChannel
}

export interface SettingsUpdate {
  outputDir?: string
  headless?: boolean
  startMaximized?: boolean
  csvDelimiter?: ',' | ';'
  browserChannel?: BrowserChannel
}

export interface AppSnapshot {
  settings: PublicSettings
  flows: FlowState[]
  auth: AuthState
  browser: BrowserSetupState
}

export interface RobotApi {
  getSnapshot(): Promise<AppSnapshot>
  updateSettings(update: SettingsUpdate): Promise<PublicSettings>
  chooseOutputDir(): Promise<string | null>
  openOutputDir(): Promise<void>
  setFlowUrl(flowId: string, url: string): Promise<void>
  setFlowPeriod(flowId: string, period: PeriodFilter): Promise<void>
  startFlow(flowId: string): Promise<void>
  stopFlow(flowId: string): Promise<void>
  downloadCsv(flowId: string): Promise<string | null>
  login(): Promise<void>
  logout(): Promise<void>
  onFlowUpdate(cb: (flow: FlowState) => void): () => void
  onAuthUpdate(cb: (auth: AuthState) => void): () => void
  onBrowserUpdate(cb: (state: BrowserSetupState) => void): () => void
}
