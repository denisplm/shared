import type { FlowMeta } from './types'

/**
 * Catálogo dos fluxos coletáveis. Na tela, os ativos aparecem primeiro, na ordem daqui.
 * `enabled: false` = coletor ainda não implementado (card desabilitado). Ao implementar
 * um coletor, mude para `true`.
 */
export const FLOW_CATALOG: FlowMeta[] = [
  { id: 'bacen', name: 'Bacen', valueColumn: 'total_percentual', enabled: false },
  { id: 'e-nps', name: 'e-NPS', valueColumn: 'total', enabled: false },
  { id: 'lead-time-feature', name: 'Lead Time Feature', valueColumn: 'total_dias', enabled: false },
  { id: 'deployment-frequency', name: 'Deployment Frequency', valueColumn: 'total_percentual', enabled: false },
  { id: 'testes-funcionais', name: 'Testes Funcionais', valueColumn: 'total_percentual', enabled: true },
  { id: 'testes-regressivos', name: 'Testes Regressivos', valueColumn: 'total_percentual', enabled: true },
  { id: 'change-success-rate', name: 'Change Success Rate', valueColumn: 'total_percentual', enabled: false },
  { id: 'change-impact-rate', name: 'Change Impact Rate', valueColumn: 'total_percentual', enabled: false },
  { id: 'incidentes-sla', name: 'Incidentes SLA', valueColumn: 'total_percentual', enabled: false },
  { id: 'code-churn', name: 'Code Churn', valueColumn: 'total_percentual', enabled: false },
  { id: 'code-review-time', name: 'Code Review Time', valueColumn: 'total_dias', enabled: false },
  { id: 'time-to-first-commit', name: 'Time To First Commit', valueColumn: 'total_dias', enabled: false }
]
