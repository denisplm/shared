import type { FlowMeta } from './types'

/** Catálogo dos fluxos coletáveis. A ordem aqui é a ordem exibida na tela. */
export const FLOW_CATALOG: FlowMeta[] = [
  { id: 'bacen', name: 'Bacen', valueColumn: 'total_percentual' },
  { id: 'e-nps', name: 'e-NPS', valueColumn: 'total' },
  { id: 'lead-time-feature', name: 'Lead Time Feature', valueColumn: 'total_dias' },
  { id: 'deployment-frequency', name: 'Deployment Frequency', valueColumn: 'total_percentual' },
  { id: 'testes-funcionais', name: 'Testes Funcionais', valueColumn: 'total_percentual' },
  { id: 'testes-regressivos', name: 'Testes Regressivos', valueColumn: 'total_percentual' },
  { id: 'change-success-rate', name: 'Change Success Rate', valueColumn: 'total_percentual' },
  { id: 'change-impact-rate', name: 'Change Impact Rate', valueColumn: 'total_percentual' },
  { id: 'incidentes-sla', name: 'Incidentes SLA', valueColumn: 'total_percentual' },
  { id: 'code-churn', name: 'Code Churn', valueColumn: 'total_percentual' },
  { id: 'code-review-time', name: 'Code Review Time', valueColumn: 'total_dias' },
  { id: 'time-to-first-commit', name: 'Time To First Commit', valueColumn: 'total_dias' }
]
