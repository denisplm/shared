import { useEffect, useState } from 'react'
import { PERIOD_OPTIONS, resolvePeriod } from '@shared/period'
import type { FlowState } from '@shared/types'
import type { RunAction } from '../App'
import { DownloadIcon, LogIcon, PlayIcon, StopIcon } from './Icons'

const STATUS_LABEL: Record<FlowState['status'], string> = {
  idle: 'Parado',
  authenticating: 'Autenticando',
  running: 'Coletando',
  success: 'Concluído',
  error: 'Erro',
  stopped: 'Interrompido'
}

function formatDate(iso?: string): string {
  return iso ? new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : ''
}

export function FlowCard({ flow, run }: { flow: FlowState; run: RunAction }): JSX.Element {
  const [url, setUrl] = useState(flow.url)
  const [showLogs, setShowLogs] = useState(false)
  const active = flow.status === 'running' || flow.status === 'authenticating'
  // Fluxos sem coletor implementado ficam visíveis, mas sem nenhuma ação.
  const disabled = !flow.enabled
  const locked = active || disabled
  const periodo = resolvePeriod(flow.period)

  useEffect(() => setUrl(flow.url), [flow.url])

  const saveUrl = (): void => {
    if (url.trim() !== flow.url) void run(() => window.robot.setFlowUrl(flow.id, url))
  }

  return (
    <article
      className={`card status-${flow.status}${disabled ? ' card-disabled' : ''}`}
      aria-disabled={disabled}
      title={disabled ? 'Fluxo ainda não implementado' : undefined}
    >
      <div className="card-head">
        <h3>{flow.name}</h3>
        {disabled ? (
          <span className="pill pill-disabled">Não implementado</span>
        ) : (
          <span className={`pill pill-${flow.status}`}>{STATUS_LABEL[flow.status]}</span>
        )}
      </div>

      <label className="field">
        <span>URL do dashboard</span>
        <input
          type="url"
          placeholder="https://app.powerbi.com/groups/…/reports/…"
          value={url}
          disabled={locked}
          onChange={(e) => setUrl(e.target.value)}
          onBlur={saveUrl}
          onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
        />
      </label>

      <div className="field">
        <span>Período</span>
        <div className="period-row">
          <div className="segmented" role="radiogroup" aria-label="Período">
            {PERIOD_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                role="radio"
                aria-checked={flow.period === opt.value}
                className={flow.period === opt.value ? 'active' : ''}
                disabled={locked}
                onClick={() => run(() => window.robot.setFlowPeriod(flow.id, opt.value))}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <span className="muted small period-range">
            {periodo.dataInicial} a {periodo.dataFinal}
          </span>
        </div>
      </div>

      <div className="progress" aria-label="Progresso">
        <div className="progress-bar" style={{ width: `${flow.progress}%` }} />
      </div>
      <p className="card-message" title={flow.message}>
        {flow.message}
      </p>

      <div className="card-actions">
        {active ? (
          <button className="round stop" title="Parar" onClick={() => run(() => window.robot.stopFlow(flow.id))}>
            <StopIcon />
          </button>
        ) : (
          <button
            className="round play"
            title={disabled ? 'Fluxo ainda não implementado' : 'Iniciar coleta'}
            disabled={disabled}
            onClick={() => run(() => window.robot.startFlow(flow.id))}
          >
            <PlayIcon />
          </button>
        )}
        <button
          className="btn"
          disabled={!flow.lastCsvPath || locked}
          title={flow.lastCsvPath ?? 'Nenhum CSV gerado ainda'}
          onClick={() => run(() => window.robot.downloadCsv(flow.id).then((p) => (p ? `CSV salvo em ${p}` : undefined)))}
        >
          <DownloadIcon width={16} height={16} /> CSV
        </button>
        <button
          className="btn ghost icon-btn"
          title="Logs"
          disabled={disabled || flow.logs.length === 0}
          onClick={() => setShowLogs((v) => !v)}
        >
          <LogIcon width={16} height={16} />
        </button>
        {flow.lastFinishedAt && !disabled && (
          <span className="muted small last-run">
            {formatDate(flow.lastFinishedAt)} · {flow.lastRowCount ?? 0} linha(s)
          </span>
        )}
      </div>

      {showLogs && flow.logs.length > 0 && (
        <ol className="logs">
          {flow.logs.map((l, i) => (
            <li key={i} className={`log-${l.level}`}>
              <time>{new Date(l.at).toLocaleTimeString('pt-BR')}</time> {l.message}
            </li>
          ))}
        </ol>
      )}
    </article>
  )
}
