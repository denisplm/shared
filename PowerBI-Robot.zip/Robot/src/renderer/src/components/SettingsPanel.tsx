import { useState } from 'react'
import type { BrowserChannel, PublicSettings, SettingsUpdate } from '@shared/types'
import type { RunAction } from '../App'
import { CopilotSettings } from './CopilotSettings'
import { CloseIcon, FolderIcon } from './Icons'

interface Props {
  settings: PublicSettings
  onClose(): void
  onSaved(settings: PublicSettings): void
  run: RunAction
}

export function SettingsPanel({ settings, onClose, onSaved, run }: Props): JSX.Element {
  const [outputDir, setOutputDir] = useState(settings.outputDir)
  const [headless, setHeadless] = useState(settings.headless)
  const [startMaximized, setStartMaximized] = useState(settings.startMaximized)
  const [delimiter, setDelimiter] = useState(settings.csvDelimiter)
  const [channel, setChannel] = useState<BrowserChannel>(settings.browserChannel)
  const [copilotModel, setCopilotModel] = useState(settings.copilotModel)

  const save = (): Promise<void> =>
    run(async () => {
      const update: SettingsUpdate = {
        outputDir,
        headless,
        startMaximized,
        csvDelimiter: delimiter,
        browserChannel: channel,
        copilotModel
      }
      onSaved(await window.robot.updateSettings(update))
      onClose()
    }, 'Configurações salvas.')

  const chooseDir = (): Promise<void> =>
    run(async () => {
      const dir = await window.robot.chooseOutputDir()
      if (dir) setOutputDir(dir)
    })

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside className="panel" role="dialog" aria-label="Configurações">
        <div className="panel-head">
          <h2>Configurações</h2>
          <button className="btn ghost icon-btn" onClick={onClose} title="Fechar">
            <CloseIcon />
          </button>
        </div>

        <h4>Arquivos</h4>
        <label className="field">
          <span>Pasta de destino dos CSVs</span>
          <div className="input-group">
            <input value={outputDir} onChange={(e) => setOutputDir(e.target.value)} />
            <button className="btn icon-btn" onClick={chooseDir} title="Escolher pasta">
              <FolderIcon />
            </button>
          </div>
        </label>
        <label className="field">
          <span>Separador do CSV</span>
          <select value={delimiter} onChange={(e) => setDelimiter(e.target.value as ',' | ';')}>
            <option value=";">Ponto e vírgula ( ; ) — Excel pt-BR</option>
            <option value=",">Vírgula ( , )</option>
          </select>
        </label>

        <h4>Navegador</h4>
        <label className="check">
          <input type="checkbox" checked={!headless} onChange={(e) => setHeadless(!e.target.checked)} />
          <span>Mostrar o navegador durante a coleta</span>
        </label>
        <label className="check">
          <input type="checkbox" checked={startMaximized} onChange={(e) => setStartMaximized(e.target.checked)} />
          <span>Iniciar o navegador maximizado</span>
        </label>
        <label className="field">
          <span>Navegador</span>
          <select value={channel} onChange={(e) => setChannel(e.target.value as BrowserChannel)}>
            <option value="msedge">Microsoft Edge instalado</option>
            <option value="chrome">Google Chrome instalado</option>
          </select>
        </label>

        <CopilotSettings model={copilotModel} onModelChange={setCopilotModel} run={run} />

        <div className="panel-foot">
          <button className="btn ghost" onClick={onClose}>
            Cancelar
          </button>
          <button className="btn primary" onClick={save}>
            Salvar
          </button>
        </div>
      </aside>
    </div>
  )
}
