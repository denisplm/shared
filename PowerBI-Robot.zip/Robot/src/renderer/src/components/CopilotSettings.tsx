import { useCallback, useEffect, useState } from 'react'
import type { CopilotModel, CopilotStatus } from '@shared/types'
import type { RunAction } from '../App'

interface Props {
  model: string
  onModelChange(model: string): void
  run: RunAction
}

/** Conexão com o GitHub Copilot, usado pelos fluxos para ler prints dos relatórios. */
export function CopilotSettings({ model, onModelChange, run }: Props): JSX.Element {
  const [status, setStatus] = useState<CopilotStatus | null>(null)
  const [models, setModels] = useState<CopilotModel[]>([])
  const [busy, setBusy] = useState(false)
  const [progress, setProgress] = useState('')

  const refresh = useCallback(async () => {
    const next = await window.robot.copilotStatus()
    setStatus(next)
    setModels(next.authenticated ? await window.robot.copilotModels().catch(() => []) : [])
  }, [])

  useEffect(() => {
    void refresh()
    return window.robot.onCopilotUpdate(setProgress)
  }, [refresh])

  const login = (): Promise<void> =>
    run(async () => {
      setBusy(true)
      try {
        const next = await window.robot.copilotLogin()
        await refresh()
        return next.message
      } finally {
        setBusy(false)
        setProgress('')
      }
    })

  const tone = !status ? 'checking' : status.authenticated ? 'valid' : status.available ? 'invalid' : 'error'

  return (
    <>
      <h4>GitHub Copilot</h4>
      <p className="muted small">Usado pelos fluxos que tiram print do relatório e pedem ao Copilot as linhas do CSV.</p>
      <div className="copilot-status">
        <span className={`chip auth-${tone}`}>
          <span className="dot" />
          {status ? (status.authenticated ? `Conectado${status.login ? `: ${status.login}` : ''}` : 'Não conectado') : 'Verificando…'}
        </span>
        {status && !status.authenticated && status.available && (
          <button className="btn" disabled={busy} onClick={login}>
            {busy ? 'Aguardando…' : 'Entrar no Copilot'}
          </button>
        )}
        <button className="btn ghost" disabled={busy} onClick={() => run(refresh)}>
          Verificar
        </button>
      </div>
      {(progress || (status && !status.authenticated)) && <p className="muted small">{progress || status?.message}</p>}
      <label className="field">
        <span>Modelo (precisa aceitar imagens)</span>
        <select value={model} disabled={!status?.authenticated} onChange={(e) => onModelChange(e.target.value)}>
          <option value="">Padrão do Copilot</option>
          {model && !models.some((m) => m.id === model) && <option value={model}>{model}</option>}
          {models.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name}
            </option>
          ))}
        </select>
      </label>
    </>
  )
}
