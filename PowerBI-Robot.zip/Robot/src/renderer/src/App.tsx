import { useCallback, useEffect, useState } from 'react'
import type { AppSnapshot } from '@shared/types'
import appIcon from '../../../build/icon.svg'
import { FlowCard } from './components/FlowCard'
import { FolderIcon, LogoutIcon, SettingsIcon } from './components/Icons'
import { SettingsPanel } from './components/SettingsPanel'

const AUTH_LABEL = {
  checking: 'Verificando sessão…',
  valid: 'Autenticado',
  invalid: 'Não autenticado',
  authenticating: 'Autenticando…'
} as const

export function App(): JSX.Element {
  const [snap, setSnap] = useState<AppSnapshot | null>(null)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [toast, setToast] = useState<{ text: string; kind: 'ok' | 'error' } | null>(null)

  useEffect(() => {
    window.robot.getSnapshot().then(setSnap)
    const offs = [
      window.robot.onFlowUpdate((flow) =>
        setSnap((s) => s && { ...s, flows: s.flows.map((f) => (f.id === flow.id ? flow : f)) })
      ),
      window.robot.onAuthUpdate((auth) => setSnap((s) => s && { ...s, auth }))
    ]
    return () => offs.forEach((off) => off())
  }, [])

  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => setToast(null), 4000)
    return () => clearTimeout(t)
  }, [toast])

  const run = useCallback(async (action: () => Promise<unknown>, success?: string) => {
    try {
      const result = await action()
      const text = typeof result === 'string' ? result : success
      if (text) setToast({ text, kind: 'ok' })
    } catch (err) {
      const msg = err instanceof Error ? err.message.replace(/^Error invoking remote method '[^']+': (Error: )?/, '') : String(err)
      setToast({ text: msg, kind: 'error' })
    }
  }, [])

  if (!snap) return <div className="loading">Carregando…</div>

  const { auth, flows, settings } = snap
  const done = flows.filter((f) => f.status === 'success').length

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <img className="logo" src={appIcon} alt="" />
          <div>
            <h1>PowerBI Robot</h1>
            <p className="muted">Extração de indicadores dos dashboards</p>
          </div>
        </div>
        <div className="topbar-actions">
          <span className={`chip auth-${auth.status}`} title={auth.message}>
            <span className="dot" />
            {AUTH_LABEL[auth.status]}
          </span>
          {auth.status === 'invalid' && (
            <button className="btn" onClick={() => run(() => window.robot.login(), 'Login concluído.')}>
              Entrar
            </button>
          )}
          <button className="btn icon-btn" title="Abrir pasta dos CSVs" onClick={() => run(() => window.robot.openOutputDir())}>
            <FolderIcon />
          </button>
          <button className="btn icon-btn" title="Configurações" onClick={() => setSettingsOpen(true)}>
            <SettingsIcon />
          </button>
          {(auth.status === 'valid' || auth.status === 'checking') && (
            <button
              className="btn icon-btn"
              title="Sair (encerrar sessão)"
              onClick={() =>
                window.confirm('Sair e encerrar a sessão do Power BI?') &&
                run(() => window.robot.logout(), 'Sessão encerrada.')
              }
            >
              <LogoutIcon />
            </button>
          )}
        </div>
      </header>

      {auth.status === 'authenticating' && (
        <div className="banner">
          <span>{auth.message}</span>
        </div>
      )}

      <section className="toolbar">
        <div>
          <h2>Fluxos coletáveis</h2>
          <p className="muted">
            {flows.length} fluxos · {done} concluído(s) nesta sessão · CSVs em <code>{settings.outputDir}</code>
          </p>
        </div>
      </section>

      <main className="grid">
        {flows.map((flow) => (
          <FlowCard key={flow.id} flow={flow} run={run} />
        ))}
      </main>

      {settingsOpen && (
        <SettingsPanel
          settings={settings}
          onClose={() => setSettingsOpen(false)}
          onSaved={(s) => setSnap((prev) => prev && { ...prev, settings: s })}
          run={run}
        />
      )}

      {toast && <div className={`toast ${toast.kind}`}>{toast.text}</div>}
    </div>
  )
}

export type RunAction = (action: () => Promise<unknown>, success?: string) => Promise<void>
