/** Permite `import './styles.css'` (o Vite injeta o CSS no build). */
declare module '*.css'

/** Imagens importadas viram a URL do arquivo (o ícone do app vem de build/icon.svg). */
declare module '*.svg' {
  const url: string
  export default url
}
