/** Permite `import './styles.css'` (o Vite injeta o CSS no build). */
declare module '*.css'
