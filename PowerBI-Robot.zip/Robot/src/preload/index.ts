import { contextBridge, ipcRenderer, type IpcRendererEvent } from 'electron'
import type { RobotApi } from '@shared/types'

function subscribe<T>(channel: string, cb: (payload: T) => void): () => void {
  const listener = (_e: IpcRendererEvent, payload: T): void => cb(payload)
  ipcRenderer.on(channel, listener)
  return () => ipcRenderer.removeListener(channel, listener)
}

const api: RobotApi = {
  getSnapshot: () => ipcRenderer.invoke('snapshot'),
  updateSettings: (update) => ipcRenderer.invoke('settings:update', update),
  chooseOutputDir: () => ipcRenderer.invoke('settings:chooseOutputDir'),
  openOutputDir: () => ipcRenderer.invoke('settings:openOutputDir'),
  setFlowUrl: (id, url) => ipcRenderer.invoke('flow:setUrl', id, url),
  setFlowPeriod: (id, period) => ipcRenderer.invoke('flow:setPeriod', id, period),
  startFlow: (id) => ipcRenderer.invoke('flow:start', id),
  stopFlow: (id) => ipcRenderer.invoke('flow:stop', id),
  downloadCsv: (id) => ipcRenderer.invoke('flow:download', id),
  login: () => ipcRenderer.invoke('auth:login'),
  logout: () => ipcRenderer.invoke('auth:logout'),
  onFlowUpdate: (cb) => subscribe('flow:update', cb),
  onAuthUpdate: (cb) => subscribe('auth:update', cb)
}

contextBridge.exposeInMainWorld('robot', api)
