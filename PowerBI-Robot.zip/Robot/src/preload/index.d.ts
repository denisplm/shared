import type { RobotApi } from '../shared/types'

declare global {
  interface Window {
    robot: RobotApi
  }
}
