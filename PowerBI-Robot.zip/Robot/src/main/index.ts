import './env'
import { app, BrowserWindow, dialog, ipcMain, shell } from 'electron'
import { copyFileSync, existsSync } from 'fs'
import { basename, join } from 'path'
import type { AppSnapshot, PeriodFilter, SettingsUpdate } from '@shared/types'
import { clearSession, getAuthState, login, onAuthChange, startSessionMonitor } from './auth'
import { getBrowserSetupState, onBrowserSetup } from './browser'
import { flowCsvPath } from './csv'
import { getFlowState, getFlowStates, onFlowUpdate, setFlowPeriod, setFlowUrl, startFlow, stopFlow } from './runner'
import { ensureOutputDir, getPublicSettings, updateSettings } from './settings'

let win: BrowserWindow | null = null

function createWindow(): void {
  win = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 900,
    minHeight: 600,
    title: 'PowerBI Robot',
    backgroundColor: '#f6f7f9',
    autoHideMenuBar: true,
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      contextIsolation: true
    }
  })
  win.on('closed', () => (win = null))

  if (process.env.ELECTRON_RENDERER_URL) win.loadURL(process.env.ELECTRON_RENDERER_URL)
  else win.loadFile(join(__dirname, '../renderer/index.html'))
}

function send(channel: string, payload: unknown): void {
  win?.webContents.send(channel, payload)
}

function registerIpc(): void {
  ipcMain.handle('snapshot', (): AppSnapshot => ({
    settings: getPublicSettings(),
    flows: getFlowStates(),
    auth: getAuthState(),
    browser: getBrowserSetupState()
  }))
  ipcMain.handle('settings:update', (_e, update: SettingsUpdate) => updateSettings(update))
  ipcMain.handle('settings:chooseOutputDir', async () => {
    const res = await dialog.showOpenDialog(win!, {
      title: 'Pasta de destino dos CSVs',
      defaultPath: getPublicSettings().outputDir,
      properties: ['openDirectory', 'createDirectory']
    })
    if (res.canceled || !res.filePaths[0]) return null
    updateSettings({ outputDir: res.filePaths[0] })
    return res.filePaths[0]
  })
  ipcMain.handle('settings:openOutputDir', () => shell.openPath(ensureOutputDir()))

  ipcMain.handle('flow:setUrl', (_e, id: string, url: string) => setFlowUrl(id, url))
  ipcMain.handle('flow:setPeriod', (_e, id: string, period: PeriodFilter) => setFlowPeriod(id, period))
  // Não aguarda a coleta terminar: o progresso chega pelos eventos flow:update.
  ipcMain.handle('flow:start', (_e, id: string) => void startFlow(id))
  ipcMain.handle('flow:stop', (_e, id: string) => stopFlow(id))
  ipcMain.handle('flow:download', async (_e, id: string) => {
    const current = flowCsvPath(getPublicSettings().outputDir, id)
    const csv = existsSync(current) ? current : getFlowState(id)?.lastCsvPath
    if (!csv || !existsSync(csv)) throw new Error('Nenhum CSV disponível para este fluxo.')
    const res = await dialog.showSaveDialog(win!, {
      title: 'Salvar CSV',
      defaultPath: join(app.getPath('downloads'), basename(csv)),
      filters: [{ name: 'CSV', extensions: ['csv'] }]
    })
    if (res.canceled || !res.filePath) return null
    copyFileSync(csv, res.filePath)
    return res.filePath
  })

  ipcMain.handle('auth:login', () => login())
  ipcMain.handle('auth:logout', () => clearSession())

  onFlowUpdate((flow) => {
    send('flow:update', flow)
    console.log(`[flow:${flow.id}] ${flow.status} ${flow.progress}% ${flow.message}`)
  })
  onAuthChange((auth) => {
    send('auth:update', auth)
    console.log(`[auth] ${auth.status} ${auth.message}`)
  })
  onBrowserSetup((state) => send('browser:update', state))
}

if (!app.requestSingleInstanceLock()) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (win?.isMinimized()) win.restore()
    win?.focus()
  })
  app.whenReady().then(() => {
    app.setAppUserModelId('com.powerbirobot.app')
    registerIpc()
    createWindow()
    startSessionMonitor()
    app.on('activate', () => BrowserWindow.getAllWindows().length === 0 && createWindow())
  })
  app.on('window-all-closed', () => app.quit())
}
