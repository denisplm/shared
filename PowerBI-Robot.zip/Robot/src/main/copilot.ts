import { shell } from 'electron'
import { dirname, join } from 'path'
import { existsSync } from 'fs'
import { createRequire } from 'module'
import { CopilotClient, RuntimeConnection, type CopilotSession } from '@github/copilot-sdk'
import type { CopilotModel, CopilotStatus, ValueColumn } from '@shared/types'
import type { IndicatorRow } from './csv'
import { getSettings } from './settings'

/**
 * Integração com o GitHub Copilot SDK: envia uma imagem (print de um visual do
 * Power BI) e recebe as linhas do CSV (nome_tribo, mes_ano_competencia, valor).
 *
 * O runtime do Copilot vem no pacote npm @github/copilot-sdk-<plataforma> (nada é
 * baixado do GitHub) e é executado direto da pasta do app — o SDK, por padrão,
 * copiaria para %LOCALAPPDATA%, que a política corporativa pode bloquear.
 */

const REQUEST_TIMEOUT_MS = 3 * 60_000
const LOGIN_TIMEOUT_MS = 10 * 60_000

let clientPromise: Promise<CopilotClient> | null = null
let loginPromise: Promise<CopilotStatus> | null = null

/** Executável do runtime dentro do pacote da plataforma (fora do app.asar quando empacotado). */
function bundledRuntimePath(): string | undefined {
  const pkg = `@github/copilot-sdk-${process.platform}-${process.arch}`
  try {
    // O pacote da plataforma pode ficar aninhado dentro do SDK: resolve a partir dele.
    const fromSdk = createRequire(require.resolve('@github/copilot-sdk'))
    const root = dirname(fromSdk.resolve(`${pkg}/package.json`)).replace(/app\.asar([\\/])/, 'app.asar.unpacked$1')
    const exe = join(root, 'prebuilds', `${process.platform}-${process.arch}`, process.platform === 'win32' ? 'copilot-runtime.exe' : 'copilot-runtime')
    return existsSync(exe) ? exe : undefined
  } catch {
    return undefined
  }
}

function getClient(): Promise<CopilotClient> {
  clientPromise ??= (async () => {
    const runtime = bundledRuntimePath()
    const client = new CopilotClient({
      logLevel: 'error',
      ...(runtime ? { connection: RuntimeConnection.forStdio({ path: runtime }) } : {})
    })
    await client.start()
    return client
  })().catch((err) => {
    clientPromise = null
    throw err
  })
  return clientPromise
}

export async function stopCopilot(): Promise<void> {
  const pending = clientPromise
  clientPromise = null
  if (pending) await (await pending.catch(() => null))?.stop().catch(() => undefined)
}

function errorMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err)
}

export async function getCopilotStatus(): Promise<CopilotStatus> {
  try {
    const auth = await (await getClient()).getAuthStatus()
    return auth.isAuthenticated
      ? { available: true, authenticated: true, login: auth.login, message: `Conectado como ${auth.login ?? 'usuário GitHub'}.` }
      : { available: true, authenticated: false, message: 'Clique em "Entrar no Copilot" e autorize no navegador com sua conta GitHub da empresa.' }
  } catch (err) {
    return { available: false, authenticated: false, message: `Copilot indisponível: ${errorMessage(err)}` }
  }
}

/** Modelos do Copilot que aceitam imagem (o print do relatório). */
export async function listVisionModels(): Promise<CopilotModel[]> {
  const models = await (await getClient()).listModels()
  return models
    .filter((m) => m.capabilities?.supports?.vision && m.policy?.state !== 'disabled')
    .map((m) => ({ id: m.id, name: m.name }))
}

async function newSession(model?: string): Promise<CopilotSession> {
  return (await getClient()).createSession({
    model: model || undefined,
    // Só leitura de imagem: nenhuma ferramenta (arquivos, terminal…) é liberada.
    availableTools: [],
    onPermissionRequest: async () => ({ kind: 'reject' })
  })
}

/**
 * Login interativo no GitHub (OAuth no navegador padrão). As credenciais ficam
 * guardadas pelo runtime do Copilot e valem para as próximas execuções.
 */
export function loginCopilot(onUpdate: (message: string) => void): Promise<CopilotStatus> {
  loginPromise ??= doLogin(onUpdate).finally(() => {
    loginPromise = null
  })
  return loginPromise
}

async function doLogin(onUpdate: (message: string) => void): Promise<CopilotStatus> {
  const session = await newSession()
  try {
    const login = session.rpc.accounts.login
    const { flowId, step: first } = await login.begin({ kind: 'githubDotCom' })
    const deadline = Date.now() + LOGIN_TIMEOUT_MS
    let step = first
    while (Date.now() < deadline) {
      switch (step.kind) {
        case 'open-url':
          onUpdate('Autorize o acesso na janela do navegador que foi aberta.')
          await shell.openExternal(step.url)
          break
        case 'awaiting':
        case 'needs-interaction':
          onUpdate('Aguardando a autorização no navegador…')
          break
        case 'input-required':
          await login.cancel({ flowId })
          throw new Error(`O GitHub pediu uma informação adicional: ${step.prompt}`)
        case 'error':
          throw new Error(step.message)
        case 'completed':
          if (step.result.status !== 'completed') throw new Error(`Login não concluído (${step.result.status}).`)
          return await getCopilotStatus()
      }
      step = await login.advance({ flowId })
    }
    await login.cancel({ flowId }).catch(() => undefined)
    throw new Error('Tempo esgotado aguardando a autorização no navegador.')
  } finally {
    await session.disconnect().catch(() => undefined)
  }
}

const ROWS_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['linhas'],
  properties: {
    linhas: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['nome_tribo', 'mes_ano_competencia', 'valor'],
        properties: {
          nome_tribo: { type: 'string' },
          mes_ano_competencia: { type: 'string', description: 'MM/AAAA' },
          valor: { type: ['number', 'null'] }
        }
      }
    }
  }
}

export interface ImageToRowsRequest {
  /** Caminho absoluto da imagem (PNG/JPG). */
  imagePath: string
  /** Nome do indicador (ex.: "Code Churn"). */
  indicator: string
  valueColumn: ValueColumn
  /** Competência padrão (MM/AAAA) quando a imagem não mostra o mês. */
  defaultMesAno: string
  /** Orientações específicas do fluxo: qual visual ler, colunas, filtros… */
  instructions?: string
}

const VALUE_HINT: Record<ValueColumn, string> = {
  total: 'número absoluto',
  total_dias: 'quantidade de dias (número, sem a palavra "dias")',
  total_percentual: 'percentual como número, sem o símbolo % (ex.: 87,5% → 87.5)'
}

function buildPrompt(req: ImageToRowsRequest): string {
  return [
    `A imagem é um print de um relatório do Power BI com o indicador "${req.indicator}".`,
    'Extraia os dados como linhas de uma tabela com os campos:',
    '- nome_tribo: nome da tribo/equipe exatamente como aparece na imagem;',
    `- mes_ano_competencia: mês/ano no formato MM/AAAA (se a imagem não mostrar o mês, use ${req.defaultMesAno});`,
    `- valor: ${VALUE_HINT[req.valueColumn]}; use null se o valor estiver vazio ou ilegível.`,
    'Não invente dados: inclua só o que está visível. Se não houver dados, retorne a lista vazia.',
    req.instructions ? `Orientações para este relatório: ${req.instructions}` : '',
    'Responda somente com JSON no formato {"linhas": [{"nome_tribo": "...", "mes_ano_competencia": "MM/AAAA", "valor": 0}]}.'
  ]
    .filter(Boolean)
    .join('\n')
}

/** Aceita a resposta em JSON puro ou dentro de um bloco ```json. */
function parseRows(content: string): IndicatorRow[] {
  const json = content.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1] ?? content.slice(content.indexOf('{'), content.lastIndexOf('}') + 1)
  const parsed = JSON.parse(json) as { linhas?: unknown }
  if (!Array.isArray(parsed.linhas)) throw new Error('Resposta do Copilot sem a lista "linhas".')
  return parsed.linhas.map((item, i) => {
    const row = item as Record<string, unknown>
    if (typeof row.nome_tribo !== 'string' || typeof row.mes_ano_competencia !== 'string') {
      throw new Error(`Linha ${i + 1} da resposta do Copilot está incompleta.`)
    }
    const valor = typeof row.valor === 'number' ? row.valor : typeof row.valor === 'string' ? Number(row.valor.replace(',', '.')) : null
    return {
      nome_tribo: row.nome_tribo.trim(),
      mes_ano_competencia: row.mes_ano_competencia.trim(),
      valor: valor === null || Number.isNaN(valor) ? null : valor
    }
  })
}

/** Envia a imagem ao Copilot e devolve as linhas do CSV. */
export async function imageToRows(req: ImageToRowsRequest): Promise<IndicatorRow[]> {
  const status = await getCopilotStatus()
  if (!status.authenticated) throw new Error(`Copilot: ${status.message}`)

  const session = await newSession(getSettings().copilotModel)
  try {
    const attachments = [{ type: 'file' as const, path: req.imagePath }]
    const prompt = buildPrompt(req)
    let reply
    try {
      // Saída estruturada (JSON validado pelo schema), quando o modelo suporta.
      reply = await session.sendAndWait({ prompt, attachments, responseSchema: ROWS_SCHEMA }, REQUEST_TIMEOUT_MS)
    } catch {
      reply = await session.sendAndWait({ prompt, attachments }, REQUEST_TIMEOUT_MS)
    }
    const content = reply?.data.content
    if (!content) throw new Error('O Copilot não respondeu.')
    return parseRows(content)
  } finally {
    await session.disconnect().catch(() => undefined)
  }
}
