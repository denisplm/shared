import { app } from 'electron'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'fs'
import { dirname, join } from 'path'
import type { BrowserChannel, PeriodFilter, PublicSettings, SettingsUpdate } from '@shared/types'
import { SETTINGS_FILE } from './env'

export interface FlowSettings {
  url: string
  period?: PeriodFilter
  lastCsvPath?: string
  lastFinishedAt?: string
  lastRowCount?: number
}

interface StoredSettings {
  outputDir: string
  headless: boolean
  startMaximized: boolean
  csvDelimiter: ',' | ';'
  browserChannel: BrowserChannel
  flows: Record<string, FlowSettings>
}

/** Padrão: Microsoft Edge, que já vem instalado no Windows 11. */
function defaultBrowserChannel(): BrowserChannel {
  return 'msedge'
}

function defaults(): StoredSettings {
  return {
    outputDir: join(app.getPath('documents'), 'PowerBI Robot'),
    headless: true,
    startMaximized: true,
    csvDelimiter: ';',
    browserChannel: defaultBrowserChannel(),
    flows: {}
  }
}

let cache: StoredSettings | null = null

function load(): StoredSettings {
  if (cache) return cache
  try {
    // Versões anteriores guardavam e-mail e senha: descarta esses campos.
    const { email: _email, passwordEnc: _passwordEnc, ...saved } = JSON.parse(readFileSync(SETTINGS_FILE, 'utf-8'))
    cache = { ...defaults(), ...saved }
    // A opção de Chromium baixado foi removida: passa a usar o navegador instalado.
    const legacyChromium = !['msedge', 'chrome'].includes(cache!.browserChannel)
    if (legacyChromium) cache!.browserChannel = defaultBrowserChannel()
    if (_email !== undefined || _passwordEnc !== undefined || legacyChromium) save()
  } catch {
    cache = defaults()
  }
  return cache!
}

function save(): void {
  mkdirSync(dirname(SETTINGS_FILE), { recursive: true })
  writeFileSync(SETTINGS_FILE, JSON.stringify(load(), null, 2), 'utf-8')
}

export function getSettings(): Readonly<StoredSettings> {
  return load()
}

export function getPublicSettings(): PublicSettings {
  const s = load()
  return {
    outputDir: s.outputDir,
    headless: s.headless,
    startMaximized: s.startMaximized,
    csvDelimiter: s.csvDelimiter,
    browserChannel: s.browserChannel
  }
}

export function updateSettings(update: SettingsUpdate): PublicSettings {
  const s = load()
  if (update.outputDir !== undefined) s.outputDir = update.outputDir
  if (update.headless !== undefined) s.headless = update.headless
  if (update.startMaximized !== undefined) s.startMaximized = update.startMaximized
  if (update.csvDelimiter !== undefined) s.csvDelimiter = update.csvDelimiter
  if (update.browserChannel !== undefined) s.browserChannel = update.browserChannel
  save()
  return getPublicSettings()
}

export function getFlowSettings(flowId: string): FlowSettings {
  return load().flows[flowId] ?? { url: '' }
}

export function updateFlowSettings(flowId: string, patch: Partial<FlowSettings>): void {
  const s = load()
  s.flows[flowId] = { ...getFlowSettings(flowId), ...patch }
  save()
}

export function ensureOutputDir(): string {
  const dir = load().outputDir
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
  return dir
}
