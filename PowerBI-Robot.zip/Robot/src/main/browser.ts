import { screen } from 'electron'
import { chromium, type Browser, type LaunchOptions } from 'playwright-core'
import type { BrowserChannel } from '@shared/types'
import { enforceHumanTyping } from './human'
import { getSettings } from './settings'

const BROWSER_NAME: Record<BrowserChannel, string> = {
  msedge: 'Microsoft Edge',
  chrome: 'Google Chrome'
}

/** Argumentos do navegador para abrir a janela maximizada. */
function maximizedArgs(): string[] {
  // No Windows basta --start-maximized; no macOS ele é ignorado, então a janela
  // recebe o tamanho da área útil da tela.
  if (process.platform !== 'darwin') return ['--start-maximized']
  const { x, y, width, height } = screen.getPrimaryDisplay().workArea
  return ['--start-maximized', `--window-position=${x},${y}`, `--window-size=${width},${height}`]
}

/**
 * Abre o Edge ou o Chrome instalado no computador (nada é baixado), conforme
 * a configuração "Navegador".
 */
export async function launchBrowser(opts: { headless: boolean }): Promise<Browser> {
  const { browserChannel: channel, startMaximized } = getSettings()
  const maximized = startMaximized && !opts.headless
  const options: LaunchOptions = {
    headless: opts.headless,
    channel,
    args: ['--disable-blink-features=AutomationControlled', ...(maximized ? maximizedArgs() : [])]
  }
  let browser: Browser
  try {
    browser = await chromium.launch(options)
  } catch (err) {
    if (err instanceof Error && /is not found at|not found|doesn't exist/i.test(err.message)) {
      const other = channel === 'msedge' ? 'chrome' : 'msedge'
      throw new Error(
        `${BROWSER_NAME[channel]} não encontrado neste computador. Instale-o ou escolha ${BROWSER_NAME[other]} em Configurações → Navegador.`
      )
    }
    throw err
  }
  const newContext = browser.newContext.bind(browser)
  browser.newContext = async (contextOptions) => {
    // Maximizado, a página ocupa a janela inteira em vez de um viewport fixo.
    const context = await newContext(maximized ? { ...contextOptions, viewport: null } : contextOptions)
    // Toda página aberta passa a digitar como humano (ver enforceHumanTyping).
    context.on('page', enforceHumanTyping)
    return context
  }
  return browser
}
