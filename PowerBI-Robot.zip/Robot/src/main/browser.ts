import { spawn } from 'child_process'
import { screen } from 'electron'
import { dirname, join } from 'path'
import type { Browser, LaunchOptions } from 'playwright-core'
import type { BrowserSetupState } from '@shared/types'
import { BROWSERS_PATH } from './env'
import { enforceHumanTyping } from './human'
import { getSettings } from './settings'

type SetupListener = (state: BrowserSetupState) => void

let setupState: BrowserSetupState = { installing: false, message: '' }
let installPromise: Promise<void> | null = null
const listeners = new Set<SetupListener>()

export function onBrowserSetup(cb: SetupListener): void {
  listeners.add(cb)
}

export function getBrowserSetupState(): BrowserSetupState {
  return setupState
}

function emit(state: BrowserSetupState): void {
  setupState = state
  listeners.forEach((cb) => cb(state))
}

/** Caminho do CLI do playwright-core, fora do app.asar quando empacotado. */
function playwrightCli(): string {
  const pkg = require.resolve('playwright-core/package.json')
  return join(dirname(pkg), 'cli.js').replace(/app\.asar([\\/])/, 'app.asar.unpacked$1')
}

/** Baixa o Chromium do Playwright para a pasta do usuário (uma única vez). */
export function installChromium(): Promise<void> {
  if (installPromise) return installPromise
  installPromise = new Promise<void>((resolve, reject) => {
    emit({ installing: true, message: 'Baixando Chromium (somente na primeira execução)…' })
    const child = spawn(process.execPath, [playwrightCli(), 'install', 'chromium'], {
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', PLAYWRIGHT_BROWSERS_PATH: BROWSERS_PATH },
      windowsHide: true
    })
    let output = ''
    const onData = (chunk: Buffer): void => {
      const text = chunk.toString()
      output += text
      const pct = text.match(/(\d+)%/g)?.pop()
      if (pct) emit({ installing: true, message: `Baixando Chromium… ${pct}` })
    }
    child.stdout.on('data', onData)
    child.stderr.on('data', onData)
    child.on('error', reject)
    child.on('close', (code) => {
      if (code === 0) {
        emit({ installing: false, message: 'Chromium pronto.' })
        resolve()
      } else {
        emit({ installing: false, message: 'Falha ao baixar o Chromium.' })
        reject(new Error(`Falha ao instalar o Chromium (código ${code}).\n${output.slice(-800)}`))
      }
    })
  }).finally(() => {
    installPromise = null
  })
  return installPromise
}

function isMissingExecutable(err: unknown): boolean {
  return err instanceof Error && /Executable doesn't exist|browserType\.launch.*not found|please run.*install/i.test(err.message)
}

/** Argumentos do Chromium para abrir a janela maximizada. */
function maximizedArgs(): string[] {
  // No Windows basta --start-maximized; no macOS ele é ignorado, então a janela
  // recebe o tamanho da área útil da tela.
  if (process.platform !== 'darwin') return ['--start-maximized']
  const { x, y, width, height } = screen.getPrimaryDisplay().workArea
  return ['--start-maximized', `--window-position=${x},${y}`, `--window-size=${width},${height}`]
}

/** Abre o navegador; instala o Chromium automaticamente se ainda não existir. */
export async function launchBrowser(opts: { headless: boolean }): Promise<Browser> {
  const { browserChannel: channel, startMaximized } = getSettings()
  const maximized = startMaximized && !opts.headless
  const options: LaunchOptions = {
    headless: opts.headless,
    channel: channel === 'chromium' ? undefined : channel,
    args: ['--disable-blink-features=AutomationControlled', ...(maximized ? maximizedArgs() : [])]
  }
  // Import tardio: o playwright-core lê PLAYWRIGHT_BROWSERS_PATH (definido em env.ts) ao carregar.
  const { chromium } = await import('playwright-core')
  let browser: Browser
  try {
    browser = await chromium.launch(options)
  } catch (err) {
    if (channel !== 'chromium' || !isMissingExecutable(err)) throw err
    await installChromium()
    browser = await chromium.launch(options)
  }
  const newContext = browser.newContext.bind(browser)
  browser.newContext = async (contextOptions) => {
    // Maximizado, a página ocupa a janela inteira em vez de um viewport fixo.
    const context = await newContext(maximized ? { ...contextOptions, viewport: null } : contextOptions)
    // Toda página aberta passa a digitar como humano (ver enforceHumanTyping).
    context.on('page', enforceHumanTyping)
    return context
  }
  return browser
}
