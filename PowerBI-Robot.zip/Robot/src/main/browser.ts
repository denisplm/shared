import { screen } from 'electron'
import { chromium, type Browser, type LaunchOptions } from 'playwright-core'
import type { BrowserChannel } from '@shared/types'
import { enforceHumanTyping } from './human'
import { getSettings, pageLoadTimeoutMs } from './settings'

const BROWSER_NAME: Record<BrowserChannel, string> = {
  msedge: 'Microsoft Edge',
  chrome: 'Google Chrome'
}

/** Argumentos do navegador para abrir a janela maximizada. */
function maximizedArgs(): string[] {
  // No Windows basta --start-maximized; no macOS ele é ignorado, então a janela
  // recebe o tamanho da área útil da tela.
  if (process.platform !== 'darwin') return ['--start-maximized']
  const { x, y, width, height } = screen.getPrimaryDisplay().workArea
  return ['--start-maximized', `--window-position=${x},${y}`, `--window-size=${width},${height}`]
}

const LAUNCH_ATTEMPTS = 3

/**
 * Na primeira abertura com um perfil novo, o Edge (às vezes por políticas
 * corporativas) pode encerrar o processo logo após iniciar — o Playwright acusa
 * "Target page, context or browser has been closed". Uma nova tentativa resolve.
 */
async function launchWithRetry(options: LaunchOptions, channel: BrowserChannel): Promise<Browser> {
  for (let attempt = 1; ; attempt++) {
    try {
      return await chromium.launch(options)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      if (/is not found at|not found|doesn't exist/i.test(message)) {
        const other = channel === 'msedge' ? 'chrome' : 'msedge'
        throw new Error(
          `${BROWSER_NAME[channel]} não encontrado neste computador. Instale-o ou escolha ${BROWSER_NAME[other]} em Configurações → Navegador.`
        )
      }
      const closedOnStart = /has been closed|Target closed|browser has disconnected/i.test(message)
      if (closedOnStart && attempt < LAUNCH_ATTEMPTS) {
        console.warn(`[browser] ${BROWSER_NAME[channel]} fechou ao iniciar; nova tentativa (${attempt + 1}/${LAUNCH_ATTEMPTS}).`)
        await new Promise((resolve) => setTimeout(resolve, 1500 * attempt))
        continue
      }
      // O erro do Playwright traz o log completo do navegador; mostra só o essencial.
      console.error(message)
      throw new Error(
        closedOnStart
          ? `Não foi possível abrir o ${BROWSER_NAME[channel]}: ele fechou logo ao iniciar (${LAUNCH_ATTEMPTS} tentativas). Tente novamente.`
          : `Não foi possível abrir o ${BROWSER_NAME[channel]}: ${message.split(/\n|Browser logs:/)[0].trim()}`
      )
    }
  }
}

/**
 * Abre o Edge ou o Chrome instalado no computador (nada é baixado), conforme
 * a configuração "Navegador".
 */
export async function launchBrowser(opts: { headless: boolean }): Promise<Browser> {
  const { browserChannel: channel, startMaximized } = getSettings()
  const maximized = startMaximized && !opts.headless
  const options: LaunchOptions = {
    headless: opts.headless,
    channel,
    args: ['--disable-blink-features=AutomationControlled', ...(maximized ? maximizedArgs() : [])]
  }
  const browser = await launchWithRetry(options, channel)
  const newContext = browser.newContext.bind(browser)
  browser.newContext = async (contextOptions) => {
    // Maximizado, a página ocupa a janela inteira em vez de um viewport fixo.
    const context = await newContext(maximized ? { ...contextOptions, viewport: null } : contextOptions)
    // Navegações (goto, waitForURL…) usam o tempo de espera das Configurações.
    context.setDefaultNavigationTimeout(pageLoadTimeoutMs())
    // Toda página aberta passa a digitar como humano (ver enforceHumanTyping).
    context.on('page', enforceHumanTyping)
    return context
  }
  return browser
}
