import type { Browser } from 'playwright-core'
import { FLOW_CATALOG } from '@shared/flows'
import { DEFAULT_PERIOD, resolvePeriod } from '@shared/period'
import type { FlowLog, FlowState, PeriodFilter } from '@shared/types'
import { navigateWithSession, saveSession, sessionContextOptions } from './auth'
import { launchBrowser } from './browser'
import { existsSync } from 'fs'
import { ensureFlowCsv, flowCsvPath, writeFlowCsv, type IndicatorRow } from './csv'
import { getCollector } from './flows'
import { humanClick, humanPress, humanType, pause } from './human'
import { throwIfAborted } from './flows/helpers'
import type { FlowContext } from './flows/types'
import { ensureOutputDir, getFlowSettings, getSettings, updateFlowSettings } from './settings'

type FlowListener = (flow: FlowState) => void

const MAX_LOGS = 200
const states = new Map<string, FlowState>()
const running = new Map<string, AbortController>()
const listeners = new Set<FlowListener>()

for (const meta of FLOW_CATALOG) {
  const saved = getFlowSettings(meta.id)
  const csv = flowCsvPath(getSettings().outputDir, meta.id)
  states.set(meta.id, {
    ...meta,
    url: saved.url,
    period: saved.period ?? DEFAULT_PERIOD,
    status: 'idle',
    progress: 0,
    message: !meta.enabled
      ? 'Fluxo ainda não implementado.'
      : saved.lastFinishedAt
        ? 'Última coleta disponível para download.'
        : 'Pronto para coletar.',
    logs: [],
    lastCsvPath: existsSync(csv) ? csv : undefined,
    lastFinishedAt: saved.lastFinishedAt,
    lastRowCount: saved.lastRowCount
  })
}

export function onFlowUpdate(cb: FlowListener): void {
  listeners.add(cb)
}

export function getFlowStates(): FlowState[] {
  return FLOW_CATALOG.map((m) => states.get(m.id)!)
}

export function getFlowState(id: string): FlowState | undefined {
  return states.get(id)
}

function patch(id: string, update: Partial<FlowState>): void {
  const next = { ...states.get(id)!, ...update }
  states.set(id, next)
  listeners.forEach((cb) => cb(next))
}

function log(id: string, message: string, level: FlowLog['level'] = 'info'): void {
  const logs = [...states.get(id)!.logs, { at: new Date().toISOString(), level, message }].slice(-MAX_LOGS)
  patch(id, { logs })
}

export function setFlowUrl(id: string, url: string): void {
  if (!states.get(id)?.enabled) return
  updateFlowSettings(id, { url: url.trim() })
  patch(id, { url: url.trim() })
}

export function setFlowPeriod(id: string, period: PeriodFilter): void {
  const flow = states.get(id)
  if (!flow?.enabled || running.has(id)) return
  updateFlowSettings(id, { period })
  patch(id, { period })
}

export function stopFlow(id: string): void {
  running.get(id)?.abort()
}

export function startFlow(id: string): Promise<void> {
  if (running.has(id) || !states.has(id)) return Promise.resolve()
  // Lança na hora (não numa promise): o IPC dispara a coleta sem aguardar o resultado.
  if (!states.get(id)!.enabled) throw new Error('Este fluxo ainda não foi implementado.')
  const controller = new AbortController()
  running.set(id, controller)
  return runFlow(id, controller.signal).finally(() => running.delete(id))
}

async function runFlow(id: string, signal: AbortSignal): Promise<void> {
  const meta = states.get(id)!
  const url = getFlowSettings(id).url.trim()
  let browser: Browser | null = null
  const closeBrowser = (): void => void browser?.close().catch(() => undefined)
  signal.addEventListener('abort', closeBrowser)

  patch(id, { status: 'running', progress: 2, message: 'Iniciando…', logs: [] })
  log(id, `Iniciando coleta de ${meta.name}.`)

  try {
    patch(id, { progress: 10, message: 'Abrindo navegador…' })
    browser = await launchBrowser({ headless: getSettings().headless })
    throwIfAborted(signal)
    const page = await (await browser.newContext(sessionContextOptions())).newPage()

    patch(id, { progress: 20, message: 'Validando autenticação…' })
    if (!(await navigateWithSession(page, url))) {
      throw new Error('Não autenticado ou sessão expirada — clique em Entrar e inicie o fluxo novamente.')
    }
    log(id, 'Sessão válida.')
    await collectAndSave(id, url, page, signal)
  } catch (err) {
    if (signal.aborted) {
      log(id, 'Coleta interrompida pelo usuário.', 'warn')
      patch(id, { status: 'stopped', progress: 0, message: 'Interrompido.' })
    } else {
      const message = err instanceof Error ? err.message : String(err)
      log(id, message, 'error')
      patch(id, { status: 'error', message: `Erro: ${message.split('\n')[0]}` })
    }
    guaranteeCsv(id)
  } finally {
    signal.removeEventListener('abort', closeBrowser)
    closeBrowser()
  }
}

/** Após erro/interrupção, garante que o fluxo tenha seu CSV (sem apagar a coleta anterior). */
function guaranteeCsv(id: string): void {
  try {
    const file = ensureFlowCsv(ensureOutputDir(), id, states.get(id)!.valueColumn, getSettings().csvDelimiter)
    if (file) patch(id, { lastCsvPath: file })
    else log(id, 'Não foi possível garantir o CSV do fluxo.', 'error')
  } catch (err) {
    log(id, `Não foi possível garantir o CSV do fluxo: ${err instanceof Error ? err.message : err}`, 'error')
  }
}

async function collectAndSave(id: string, url: string, page: FlowContext['page'], signal: AbortSignal): Promise<void> {
  const meta = states.get(id)!
  let rows: IndicatorRow[] = []
  const periodo = resolvePeriod(meta.period)
  log(id, `Filtro de período: ${periodo.label} — ${periodo.dataInicial} a ${periodo.dataFinal}.`)

  if (!url) {
    log(id, 'URL do dashboard não configurada — gerando CSV vazio.', 'warn')
  } else {
    patch(id, { progress: 30, message: 'Coletando indicadores…' })
    rows = await getCollector(id)!.collect({
      page,
      url,
      periodo,
      signal,
      progress: (progress, message) => patch(id, { progress: Math.max(30, Math.min(95, progress)), message }),
      log: (message, level) => log(id, message, level),
      human: { type: humanType, click: humanClick, press: humanPress, pause }
    })
  }
  throwIfAborted(signal)

  // Renova os cookies salvos para os próximos fluxos.
  await saveSession(page).catch(() => undefined)

  patch(id, { progress: 96, message: 'Gerando CSV…' })
  const csvPath = writeFlowCsv(ensureOutputDir(), id, meta.valueColumn, rows, getSettings().csvDelimiter)
  const finishedAt = new Date().toISOString()
  updateFlowSettings(id, { lastCsvPath: csvPath, lastFinishedAt: finishedAt, lastRowCount: rows.length })
  log(id, `CSV gerado: ${csvPath}`)
  patch(id, {
    status: 'success',
    progress: 100,
    message: `Concluído — ${rows.length} linha(s).`,
    lastCsvPath: csvPath,
    lastFinishedAt: finishedAt,
    lastRowCount: rows.length
  })
}
