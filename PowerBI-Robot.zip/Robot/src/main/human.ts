import type { Locator, Page } from 'playwright-core'

/**
 * Interações que simulam uma pessoa: cursor sobre o campo, clique, digitação
 * caractere a caractere com ritmo irregular e pausas curtas entre ações.
 * Use sempre estas funções em campos digitáveis — nunca `locator.fill()`.
 */

const between = (min: number, max: number): number => Math.round(min + Math.random() * (max - min))

const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms))

export function pause(min = 150, max = 400): Promise<void> {
  return sleep(between(min, max))
}

/** Intervalo entre teclas: maior após espaços/pontuação e, às vezes, uma hesitação. */
function keystrokeDelay(char: string): number {
  if (Math.random() < 0.06) return between(300, 700)
  if (/[\s@._\-/]/.test(char)) return between(120, 260)
  return between(55, 170)
}

export async function humanClick(locator: Locator): Promise<void> {
  await locator.scrollIntoViewIfNeeded().catch(() => undefined)
  await locator.hover().catch(() => undefined)
  await pause(120, 350)
  await locator.click({ delay: between(40, 120) })
}

/** Clica no campo, limpa o conteúdo (Ctrl/Cmd+A, Backspace) e digita como uma pessoa. */
export async function humanType(locator: Locator, text: string): Promise<void> {
  await humanClick(locator)
  if (await locator.inputValue().catch(() => '')) {
    await locator.press('ControlOrMeta+A')
    await pause(80, 180)
    await locator.press('Backspace')
    await pause(150, 300)
  }
  for (const char of text) {
    await locator.pressSequentially(char)
    await sleep(keystrokeDelay(char))
  }
  await pause(200, 500)
}

/** Pressiona uma tecla (ex.: 'Enter', 'Tab') após uma pausa natural. */
export async function humanPress(locator: Locator, key: string): Promise<void> {
  await pause(150, 400)
  await locator.press(key, { delay: between(40, 110) })
}

let guardInstalled = false

/**
 * Garante a digitação humana em todo o app: redireciona `locator.fill()` e
 * `page.fill()` do Playwright para `humanType`, inclusive em coletores futuros.
 */
export function enforceHumanTyping(page: Page): void {
  if (guardInstalled) return
  guardInstalled = true
  const locatorProto = Object.getPrototypeOf(page.locator('body')) as Locator
  locatorProto.fill = function (this: Locator, value: string) {
    return humanType(this, value)
  }
  const pageProto = Object.getPrototypeOf(page) as Page
  pageProto.fill = function (this: Page, selector: string, value: string) {
    return humanType(this.locator(selector), value)
  }
}
