import { existsSync, mkdirSync, rmSync } from 'fs'
import { dirname } from 'path'
import type { BrowserContextOptions, Page } from 'playwright-core'
import type { AuthState } from '@shared/types'
import { launchBrowser } from './browser'
import { SESSION_FILE } from './env'

export const POWERBI_HOME = 'https://app.powerbi.com/home?noSignUpCheck=1'
const LOGIN_TIMEOUT_MS = 10 * 60_000
/** Intervalo da revalidação automática da sessão salva. */
const CHECK_INTERVAL_MS = 30 * 60_000

const NOT_AUTHENTICATED: AuthState = { status: 'invalid', message: 'Não autenticado — clique em Entrar.' }
const EXPIRED: AuthState = { status: 'invalid', message: 'Sessão expirada — clique em Entrar para autenticar novamente.' }

type AuthListener = (state: AuthState) => void

let authState: AuthState = existsSync(SESSION_FILE)
  ? { status: 'checking', message: 'Verificando a sessão salva…' }
  : NOT_AUTHENTICATED
let loginPromise: Promise<void> | null = null
let checkPromise: Promise<boolean> | null = null
const listeners = new Set<AuthListener>()

export function onAuthChange(cb: AuthListener): void {
  listeners.add(cb)
}

export function getAuthState(): AuthState {
  return authState
}

function emit(state: AuthState): void {
  authState = state
  listeners.forEach((cb) => cb(state))
}

/** Opções de contexto que reaproveitam a sessão logada, se existir. */
export function sessionContextOptions(): BrowserContextOptions {
  return {
    storageState: existsSync(SESSION_FILE) ? SESSION_FILE : undefined,
    viewport: { width: 1600, height: 900 },
    locale: 'pt-BR'
  }
}

export async function saveSession(page: Page): Promise<void> {
  mkdirSync(dirname(SESSION_FILE), { recursive: true })
  await page.context().storageState({ path: SESSION_FILE })
}

export function clearSession(): void {
  rmSync(SESSION_FILE, { force: true })
  emit(NOT_AUTHENTICATED)
}

function isPowerBiApp(url: string): boolean {
  try {
    const u = new URL(url)
    return /(^|\.)powerbi\.com$/i.test(u.hostname) && !/singleSignOn|\/signin/i.test(u.pathname)
  } catch {
    return false
  }
}

/**
 * Navega até `url` (ou à home do Power BI) e verifica se a sessão continua válida,
 * ou seja, se não houve redirecionamento para a tela de login.
 */
export async function navigateWithSession(page: Page, url: string | undefined): Promise<boolean> {
  if (!existsSync(SESSION_FILE)) {
    emit(NOT_AUTHENTICATED)
    return false
  }
  await page.goto(url || POWERBI_HOME, { waitUntil: 'domcontentloaded', timeout: 90_000 })
  if (!isPowerBiApp(page.url())) return markExpired()
  // O Power BI carrega e só depois o MSAL decide se redireciona para o login.
  try {
    await page.waitForURL((u) => !isPowerBiApp(u.toString()), { timeout: 12_000 })
    return markExpired()
  } catch {
    emit({ status: 'valid', message: 'Autenticado.' })
    return true
  }
}

function markExpired(): false {
  emit(EXPIRED)
  return false
}

/** Verifica a sessão salva num navegador oculto e atualiza o status exibido. */
export function checkSession(): Promise<boolean> {
  if (loginPromise) return Promise.resolve(false)
  if (!existsSync(SESSION_FILE)) {
    emit(NOT_AUTHENTICATED)
    return Promise.resolve(false)
  }
  checkPromise ??= (async () => {
    const browser = await launchBrowser({ headless: true })
    try {
      const page = await (await browser.newContext(sessionContextOptions())).newPage()
      const valid = await navigateWithSession(page, undefined)
      // O usuário pode ter clicado em Sair durante a verificação.
      if (!existsSync(SESSION_FILE)) {
        emit(NOT_AUTHENTICATED)
        return false
      }
      if (valid) await saveSession(page)
      return valid
    } finally {
      await browser.close().catch(() => undefined)
    }
  })()
    .catch(() => {
      // Sem rede ou navegador indisponível: não dá para afirmar que expirou.
      if (authState.status === 'checking') emit({ status: 'invalid', message: 'Não foi possível verificar a sessão.' })
      return false
    })
    .finally(() => {
      checkPromise = null
    })
  return checkPromise
}

/** Valida a sessão ao abrir o app e periodicamente, para o status refletir a expiração. */
export function startSessionMonitor(): void {
  void checkSession()
  setInterval(() => {
    if (authState.status === 'valid') void checkSession()
  }, CHECK_INTERVAL_MS)
}

/** Garante uma única janela de login por vez. */
export function login(): Promise<void> {
  loginPromise ??= doLogin().finally(() => {
    loginPromise = null
  })
  return loginPromise
}

/**
 * Abre o Power BI num navegador visível para o usuário digitar e-mail, senha e
 * aprovar o MFA. Quando o Power BI carrega, a sessão é salva.
 */
async function doLogin(): Promise<void> {
  emit({ status: 'authenticating', message: 'Abrindo janela de login…' })
  // A autenticação é sempre visível (independe de "Mostrar o navegador durante a coleta").
  const browser = await launchBrowser({ headless: false })
  try {
    const context = await browser.newContext({ viewport: null, locale: 'pt-BR' })
    const page = await context.newPage()
    let windowClosed = false
    page.on('close', () => (windowClosed = true))

    await page.goto('https://app.powerbi.com/?noSignUpCheck=1', { waitUntil: 'domcontentloaded', timeout: 90_000 })
    emit({ status: 'authenticating', message: 'Faça login e aprove o MFA na janela do navegador.' })

    const deadline = Date.now() + LOGIN_TIMEOUT_MS
    let onAppSince = 0
    while (Date.now() < deadline) {
      if (windowClosed) throw new Error('A janela de login foi fechada antes de concluir.')
      // Exige alguns segundos estável no Power BI para não confundir com redirecionamentos.
      if (isPowerBiApp(page.url())) {
        onAppSince ||= Date.now()
        if (Date.now() - onAppSince > 4_000) break
      } else {
        onAppSince = 0
      }
      await page.waitForTimeout(1_000).catch(() => undefined)
    }

    if (!isPowerBiApp(page.url())) throw new Error('Tempo esgotado aguardando o login.')
    await saveSession(page)
    emit({ status: 'valid', message: 'Autenticado.' })
  } catch (err) {
    emit({ status: 'invalid', message: `Não autenticado — ${err instanceof Error ? err.message : String(err)}` })
    throw err
  } finally {
    await browser.close().catch(() => undefined)
  }
}
