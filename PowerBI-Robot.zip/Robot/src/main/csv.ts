import { existsSync, renameSync, rmSync, writeFileSync } from 'fs'
import { join } from 'path'
import type { ValueColumn } from '@shared/types'

export interface IndicatorRow {
  nome_tribo: string
  /** Formato MM/AAAA. */
  mes_ano_competencia: string
  valor: number | string | null
}

function escape(value: unknown, delimiter: string): string {
  const s = value === null || value === undefined ? '' : String(value)
  return /["\r\n]/.test(s) || s.includes(delimiter) ? `"${s.replace(/"/g, '""')}"` : s
}

/** Caminho do único CSV do fluxo: `<pasta>/<fluxo>.csv`. */
export function flowCsvPath(outputDir: string, flowId: string): string {
  return join(outputDir, `${flowId}.csv`)
}

/**
 * Grava o CSV do fluxo (sempre, mesmo sem linhas) e retorna o caminho do arquivo.
 * Cada fluxo tem um único CSV, sobrescrito a cada execução. A gravação é atômica
 * (arquivo temporário + rename), então uma falha nunca deixa o CSV pela metade.
 */
export function writeFlowCsv(
  outputDir: string,
  flowId: string,
  valueColumn: ValueColumn,
  rows: IndicatorRow[],
  delimiter: string
): string {
  const header = ['nome_tribo', 'mes_ano_competencia', valueColumn]
  const lines = [header.join(delimiter)]
  for (const r of rows) {
    lines.push([r.nome_tribo, r.mes_ano_competencia, r.valor].map((v) => escape(v, delimiter)).join(delimiter))
  }
  const file = flowCsvPath(outputDir, flowId)
  const tmp = `${file}.tmp`
  try {
    // BOM para o Excel abrir acentos corretamente
    writeFileSync(tmp, '﻿' + lines.join('\r\n') + '\r\n', 'utf-8')
    renameSync(tmp, file)
  } catch (err) {
    rmSync(tmp, { force: true })
    const code = (err as NodeJS.ErrnoException).code
    if (code === 'EBUSY' || code === 'EPERM' || code === 'EACCES') {
      throw new Error(`Não foi possível gravar ${file} — feche o arquivo (ex.: no Excel) e tente novamente.`)
    }
    throw err
  }
  return file
}

/**
 * Garante que o CSV do fluxo exista, mesmo após erro ou interrupção: cria um
 * arquivo só com o cabeçalho se ainda não houver um. Nunca apaga dados de uma
 * coleta anterior. Retorna o caminho, ou null se não foi possível gravar.
 */
export function ensureFlowCsv(outputDir: string, flowId: string, valueColumn: ValueColumn, delimiter: string): string | null {
  const file = flowCsvPath(outputDir, flowId)
  if (existsSync(file)) return file
  try {
    return writeFlowCsv(outputDir, flowId, valueColumn, [], delimiter)
  } catch {
    return null
  }
}
