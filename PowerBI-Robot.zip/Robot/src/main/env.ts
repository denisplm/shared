import { app } from 'electron'
import { join } from 'path'

export const SESSION_FILE = join(app.getPath('userData'), 'session', 'storage-state.json')
export const SETTINGS_FILE = join(app.getPath('userData'), 'settings.json')
