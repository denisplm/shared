import { app } from 'electron'
import { join } from 'path'

export const SESSION_FILE = join(app.getPath('userData'), 'session', 'storage-state.json')
export const SETTINGS_FILE = join(app.getPath('userData'), 'settings.json')
/** Prints enviados ao Copilot, por fluxo (para conferência). */
export const SCREENSHOTS_DIR = join(app.getPath('userData'), 'prints')
