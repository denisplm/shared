import { app } from 'electron'
import { join } from 'path'

// Precisa rodar antes de qualquer import de playwright-core: o registry lê
// PLAYWRIGHT_BROWSERS_PATH ao ser carregado. O Chromium fica na pasta do
// usuário, assim o .exe não precisa embutir o navegador.
export const BROWSERS_PATH = join(app.getPath('userData'), 'ms-playwright')
process.env.PLAYWRIGHT_BROWSERS_PATH = BROWSERS_PATH

export const SESSION_FILE = join(app.getPath('userData'), 'session', 'storage-state.json')
export const SETTINGS_FILE = join(app.getPath('userData'), 'settings.json')
