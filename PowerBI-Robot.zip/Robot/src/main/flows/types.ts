import type { Locator, Page } from 'playwright-core'
import type { Competencia } from '@shared/period'
import type * as human from '../human'
import type { IndicatorRow } from '../csv'

export interface FlowContext {
  page: Page
  /** URL configurada para o fluxo (a página já está aberta nela). */
  url: string
  /**
   * Período escolhido no card ("Mês anterior" ou "Mês atual"), calculado no início
   * da coleta: dataInicial/dataFinal (DD/MM/AAAA), inicio/fim (Date), mes, ano e mesAno (MM/AAAA).
   */
  periodo: Competencia
  /** Disparado quando o usuário clica em "Parar". */
  signal: AbortSignal
  /** Atualiza a barra de progresso (0–100) e a mensagem do card. */
  progress(percent: number, message: string): void
  log(message: string, level?: 'info' | 'warn' | 'error'): void
  /**
   * Interações humanas. Em campos digitáveis use SEMPRE `human.type(locator, texto)`,
   * nunca `locator.fill()`. Para cliques prefira `human.click(locator)`.
   */
  human: {
    type: typeof human.humanType
    click: typeof human.humanClick
    press: typeof human.humanPress
    pause: typeof human.pause
  }
  /**
   * GitHub Copilot: lê um print do relatório e devolve as linhas do CSV
   * (nome_tribo, mes_ano_competencia, valor). Exige login no Copilot (Configurações).
   */
  copilot: {
    /**
     * Tira um print da página inteira ou de `target` (ex.: um visual) e pede ao
     * Copilot as linhas. O print fica salvo em %APPDATA%\PowerBI Robot\prints\<fluxo>.
     */
    screenshotToRows(options?: { target?: Locator; instructions?: string }): Promise<IndicatorRow[]>
    /** Envia uma imagem já existente (PNG/JPG, caminho absoluto) e devolve as linhas. */
    imageToRows(imagePath: string, instructions?: string): Promise<IndicatorRow[]>
  }
}

/** Coletor de um fluxo. Nome e coluna de valor vêm de src/shared/flows.ts. */
export interface FlowDefinition {
  id: string
  /** Coleta os indicadores. A página já está autenticada e aberta na URL do fluxo. */
  collect(ctx: FlowContext): Promise<IndicatorRow[]>
}
