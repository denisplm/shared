import type { Page } from 'playwright-core'
import type { Competencia } from '@shared/period'
import type * as human from '../human'
import type { IndicatorRow } from '../csv'

export interface FlowContext {
  page: Page
  /** URL configurada para o fluxo (a página já está aberta nela). */
  url: string
  /**
   * Período escolhido no card ("Mês anterior" ou "Mês atual"), calculado no início
   * da coleta: dataInicial/dataFinal (DD/MM/AAAA), inicio/fim (Date), mes, ano e mesAno (MM/AAAA).
   */
  periodo: Competencia
  /** Disparado quando o usuário clica em "Parar". */
  signal: AbortSignal
  /** Atualiza a barra de progresso (0–100) e a mensagem do card. */
  progress(percent: number, message: string): void
  log(message: string, level?: 'info' | 'warn' | 'error'): void
  /**
   * Interações humanas. Em campos digitáveis use SEMPRE `human.type(locator, texto)`,
   * nunca `locator.fill()`. Para cliques prefira `human.click(locator)`.
   */
  human: {
    type: typeof human.humanType
    click: typeof human.humanClick
    press: typeof human.humanPress
    pause: typeof human.pause
  }
}

/** Coletor de um fluxo. Nome e coluna de valor vêm de src/shared/flows.ts. */
export interface FlowDefinition {
  id: string
  /** Coleta os indicadores. A página já está autenticada e aberta na URL do fluxo. */
  collect(ctx: FlowContext): Promise<IndicatorRow[]>
}
