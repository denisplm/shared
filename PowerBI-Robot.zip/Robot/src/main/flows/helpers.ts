import type { Page } from 'playwright-core'
import { humanClick, humanPress, humanType } from '../human'
import { pageLoadTimeoutMs } from '../settings'

/** Lança erro se o usuário parou o fluxo — chame entre etapas longas. */
export function throwIfAborted(signal: AbortSignal): void {
  if (signal.aborted) throw new Error('Coleta interrompida pelo usuário.')
}

/**
 * Aguarda o relatório do Power BI terminar de renderizar os visuais. O tempo padrão
 * é o de "Tempo máximo para a página carregar" (Configurações → Navegador).
 */
export async function waitForReport(page: Page, timeoutMs = pageLoadTimeoutMs()): Promise<void> {
  await page.locator('.visualContainer, visual-container').first().waitFor({ state: 'visible', timeout: timeoutMs })
  // Spinners de carregamento dos visuais
  await page
    .locator('.powerbi-spinner, .circle.spinner')
    .first()
    .waitFor({ state: 'hidden', timeout: timeoutMs })
    .catch(() => undefined)
}

/** Seleciona uma aba (página) do relatório pelo nome exibido. */
export async function openReportPage(page: Page, name: string): Promise<void> {
  await humanClick(page.getByRole('tab', { name }).or(page.getByText(name, { exact: true })).first())
  await waitForReport(page)
}

/**
 * Exporta os dados de um visual pelo menu "Mais opções" → "Exportar dados"
 * e retorna o caminho do arquivo baixado.
 */
export async function exportVisualData(page: Page, visualTitle: string, downloadDir: string): Promise<string> {
  const visual = page.locator('visual-container, .visualContainer').filter({ hasText: visualTitle }).first()
  await visual.hover()
  await humanClick(visual.locator('[aria-label="Mais opções"], [aria-label="More options"]').first())
  await humanClick(page.getByRole('menuitem', { name: /Exportar dados|Export data/i }))
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    humanClick(page.getByRole('button', { name: /^Exportar$|^Export$/i }))
  ])
  const target = `${downloadDir}/${Date.now()}_${download.suggestedFilename()}`
  await download.saveAs(target)
  return target
}

/** Digita num filtro/slicer de busca do relatório (ex.: nome da tribo) como uma pessoa. */
export async function typeInSlicerSearch(page: Page, slicerTitle: string, text: string): Promise<void> {
  const slicer = page.locator('visual-container, .visualContainer').filter({ hasText: slicerTitle }).first()
  await humanType(slicer.locator('input[type="text"], input.searchInput').first(), text)
}

/**
 * Seleciona uma opção num slicer (segmentação) do relatório, como uma pessoa:
 * abre o slicer, pesquisa o texto quando houver campo de busca e clica na opção.
 */
export async function selectSlicerOption(page: Page, slicerTitle: string, option: string): Promise<void> {
  const slicer = page.locator('visual-container, .visualContainer').filter({ hasText: slicerTitle }).first()
  const dropdown = slicer.locator('.slicer-dropdown-menu, [role="combobox"]').first()
  if (await dropdown.isVisible().catch(() => false)) await humanClick(dropdown)
  const search = page.locator('.slicer-dropdown-popup input.searchInput, .slicerContainer input.searchInput').first()
  if (await search.isVisible().catch(() => false)) await humanType(search, option)
  await humanClick(page.locator('.slicerItemContainer, [role="option"]').filter({ hasText: option }).first())
}

/**
 * Preenche um slicer de data no modo "Entre" (data inicial e final) digitando como
 * uma pessoa, ex.: setDateRangeSlicer(page, 'Data', periodo.dataInicial, periodo.dataFinal).
 */
export async function setDateRangeSlicer(page: Page, slicerTitle: string, dataInicial: string, dataFinal: string): Promise<void> {
  const slicer = page.locator('visual-container, .visualContainer').filter({ hasText: slicerTitle }).first()
  const inputs = slicer.locator('input.date-slicer-input, input[type="text"]')
  await humanType(inputs.nth(0), dataInicial)
  await humanPress(inputs.nth(0), 'Enter')
  await humanType(inputs.nth(1), dataFinal)
  await humanPress(inputs.nth(1), 'Enter')
}

/** Normaliza datas como "jan/2025", "01/2025" ou "2025-01" para MM/AAAA. */
export function toMesAno(raw: string): string {
  const meses = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']
  const s = raw.trim().toLowerCase()
  let m = s.match(/^(\d{4})-(\d{1,2})/)
  if (m) return `${m[2].padStart(2, '0')}/${m[1]}`
  m = s.match(/^(\d{1,2})\/(\d{4})$/)
  if (m) return `${m[1].padStart(2, '0')}/${m[2]}`
  m = s.match(/^([a-zç]{3})[a-zç]*[\s/-]+(?:de\s+)?(\d{2,4})$/)
  if (m && meses.includes(m[1])) {
    const ano = m[2].length === 2 ? `20${m[2]}` : m[2]
    return `${String(meses.indexOf(m[1]) + 1).padStart(2, '0')}/${ano}`
  }
  return raw.trim()
}

/** Converte números no formato brasileiro ("1.234,5%", "12,3 dias") para number. */
export function parseNumeroBR(raw: string): number | null {
  const cleaned = raw.replace(/[^\d,.-]/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.')
  const n = parseFloat(cleaned)
  return Number.isFinite(n) ? n : null
}
