import { bacen } from './coletores/bacen'
import { eNps } from './coletores/e-nps'
import { leadTimeFeature } from './coletores/lead-time-feature'
import { deploymentFrequency } from './coletores/deployment-frequency'
import { testesFuncionais } from './coletores/testes-funcionais'
import { testesRegressivos } from './coletores/testes-regressivos'
import { changeSuccessRate } from './coletores/change-success-rate'
import { changeImpactRate } from './coletores/change-impact-rate'
import { incidentesSla } from './coletores/incidentes-sla'
import { codeChurn } from './coletores/code-churn'
import { codeReviewTime } from './coletores/code-review-time'
import { timeToFirstCommit } from './coletores/time-to-first-commit'
import type { FlowDefinition } from './types'

/** Coletores de todos os fluxos. Nomes e colunas ficam em src/shared/flows.ts. */
const COLLECTORS: FlowDefinition[] = [
  bacen,
  eNps,
  leadTimeFeature,
  deploymentFrequency,
  testesFuncionais,
  testesRegressivos,
  changeSuccessRate,
  changeImpactRate,
  incidentesSla,
  codeChurn,
  codeReviewTime,
  timeToFirstCommit,
]

export function getCollector(id: string): FlowDefinition | undefined {
  return COLLECTORS.find((f) => f.id === id)
}
