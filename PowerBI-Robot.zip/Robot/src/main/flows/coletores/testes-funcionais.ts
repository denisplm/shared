import type { ElementHandle, Locator, Page } from 'playwright-core'
import type { IndicatorRow } from '../../csv'
import { pageLoadTimeoutMs } from '../../settings'
import { throwIfAborted } from '../helpers'
import type { FlowContext, FlowDefinition } from '../types'

/**
 * Testes Funcionais — colunas: nome_tribo, mes_ano_competencia, total_percentual
 *
 * Lê a matriz "Testes Funcionais" do relatório (coluna "% Funcionais Automatizados")
 * após aplicar os filtros: Tipo de Empreendimento = Tribo e o período do card
 * (Mês anterior → "Último 1 Meses (Calendário)"; Mês atual → "Este(a) Mês").
 *
 * A página já chega autenticada (sessão salva) e aberta na URL configurada.
 */

const REPORT_LOADED_SELECTOR = 'iframe, .visualContainer, .reportCanvasContainer, canvas'
const GRID_TITLE = 'Testes Funcionais'
const VALUE_COLUMN = '% Funcionais Automatizados'
const EMPTY_VALUE = '-'
const MAX_SCROLLS = 200
/** Tempo para o Power BI reconsultar os visuais depois de mudar os filtros. */
const AFTER_FILTERS_WAIT_MS = 5000

type Human = FlowContext['human']

interface GridRow {
  tribo: string
  valor: string
}

async function waitForReportLoaded(page: Page): Promise<void> {
  await page.locator(REPORT_LOADED_SELECTOR).first().waitFor({ state: 'visible', timeout: pageLoadTimeoutMs() })
}

// ---------- filtros ----------

async function openCombobox(combo: Locator, human: Human): Promise<void> {
  if ((await combo.getAttribute('aria-expanded')) !== 'true') await human.click(combo)
}

/** Combobox customizado do Power BI (os <select> nativos ficam ocultos). */
async function selectComboOption(page: Page, human: Human, comboName: string, optionText: string): Promise<void> {
  const combo = page.getByRole('combobox', { name: comboName, exact: true })
  if ((await combo.innerText()).trim() === optionText) return
  await openCombobox(combo, human)
  await human.click(page.getByRole('option', { name: optionText, exact: true }))
}

async function applyFilters(page: Page, ctx: FlowContext): Promise<void> {
  const { human, log, periodo, signal } = ctx

  log('Limpando filtros…')
  await human.click(page.locator('[aria-label*="Limpar todas as Segmentações"]'))
  throwIfAborted(signal)

  log('Marcando Tribo em Tipo de Empreendimento…')
  await openCombobox(page.getByRole('combobox', { name: 'Tipo de Empreendimento', exact: true }), human)
  await human.click(page.getByRole('option', { name: 'Tribo', exact: true }))
  await human.pause()
  await page.keyboard.press('Escape')
  throwIfAborted(signal)

  if (periodo.filtro === 'mes_anterior') {
    log('Configurando período: Último 1 mês (Calendário)…')
    await selectComboOption(page, human, 'Faixa', 'Último')
    const duration = page.getByRole('spinbutton', { name: 'Duração' })
    await human.type(duration, '1')
    await human.press(duration, 'Tab')
    await selectComboOption(page, human, 'Período:', 'Meses (Calendário)')
  } else {
    log('Configurando período: Este(a) mês…')
    await selectComboOption(page, human, 'Faixa', 'Este(a)')
    await selectComboOption(page, human, 'Período:', 'Mês')
  }
}

// ---------- matriz Testes Funcionais ----------

async function locateGrid(page: Page): Promise<ElementHandle<Element>> {
  const timeout = pageLoadTimeoutMs()
  const findGrid = (gridTitle: string): Element | null => {
    const container = [...document.querySelectorAll('.visual-container')].find(
      (vc) =>
        [...vc.querySelectorAll('[aria-label]')].some((el) => el.getAttribute('aria-label')?.trim() === gridTitle) &&
        vc.querySelector('[role="grid"] [role="rowheader"]')
    )
    return container?.querySelector('[role="grid"]') ?? null
  }
  const handle = await page.waitForFunction(findGrid, GRID_TITLE, { timeout }).catch((err: Error) => {
    if (err.name !== 'TimeoutError') throw err
    throw new Error(
      `Matriz "${GRID_TITLE}" com linhas não apareceu em ${timeout / 1000} s. Confira o título do visual e se os filtros retornaram dados.`
    )
  })
  const grid = handle.asElement()
  if (!grid) throw new Error(`Matriz "${GRID_TITLE}" não encontrada no relatório.`)
  return grid
}

function readVisibleRows(grid: ElementHandle<Element>, valueColumn: string): Promise<GridRow[]> {
  return grid.evaluate((el, column) => {
    const header = [...el.querySelectorAll('[role="columnheader"]')].find((h) => h.textContent?.trim() === column)
    if (!header) throw new Error(`Coluna "${column}" não encontrada na matriz.`)
    const colIndex = header.getAttribute('aria-colindex')

    return [...el.querySelectorAll('[role="row"]')].flatMap((row) => {
      const rowHeader = row.querySelector('[role="rowheader"]')
      if (!rowHeader) return []
      const cell = row.querySelector(`[role="gridcell"][aria-colindex="${colIndex}"]`)
      return [{ tribo: rowHeader.textContent?.trim() ?? '', valor: cell?.textContent?.trim() ?? '' }]
    })
  }, valueColumn)
}

function normalizeValue(raw: string): string {
  const value = raw.replace('%', '').trim()
  return value === '' ? EMPTY_VALUE : value
}

/** A matriz virtualiza linhas: rola com a roda do mouse e acumula até não aparecer linha nova. */
async function extractGridRows(page: Page, signal: AbortSignal): Promise<GridRow[]> {
  const grid = await locateGrid(page)
  await grid.scrollIntoViewIfNeeded()

  const viewport = (await grid.$('.mid-viewport')) ?? grid
  const rows = new Map<string, string>()

  for (let i = 0; i < MAX_SCROLLS; i++) {
    throwIfAborted(signal)
    const before = rows.size

    for (const row of await readVisibleRows(grid, VALUE_COLUMN)) {
      // A linha de total fica fixa no rodapé da matriz, não é uma tribo.
      if (row.tribo === 'Total') continue
      rows.set(row.tribo, normalizeValue(row.valor))
    }

    if (rows.size === before) break

    const box = await viewport.boundingBox()
    if (!box) break
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2)
    await page.mouse.wheel(0, box.height * 0.8)
    await page.waitForTimeout(800)
  }

  return [...rows].map(([tribo, valor]) => ({ tribo, valor }))
}

// ---------- fluxo ----------

export const testesFuncionais: FlowDefinition = {
  id: 'testes-funcionais',
  async collect(ctx) {
    const { page, periodo, signal, progress, log } = ctx

    progress(35, 'Aguardando o relatório carregar…')
    await waitForReportLoaded(page)
    log('Relatório carregado.')
    throwIfAborted(signal)

    progress(45, `Aplicando filtros (${periodo.label})…`)
    await applyFilters(page, ctx)

    // Dá tempo para o Power BI reconsultar os visuais com os filtros novos.
    progress(60, 'Aguardando o relatório atualizar…')
    await page.waitForTimeout(AFTER_FILTERS_WAIT_MS)
    throwIfAborted(signal)

    progress(70, 'Lendo a matriz Testes Funcionais…')
    const gridRows = await extractGridRows(page, signal)
    log(`${gridRows.length} linha(s) lida(s) da matriz.`)

    const rows: IndicatorRow[] = gridRows.map(({ tribo, valor }) => ({
      nome_tribo: tribo,
      mes_ano_competencia: periodo.mesAno,
      valor
    }))
    progress(90, `${rows.length} tribo(s) coletada(s).`)
    return rows
  }
}
