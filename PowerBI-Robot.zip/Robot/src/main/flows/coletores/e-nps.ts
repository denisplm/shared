import type { IndicatorRow } from '../../csv'
import { throwIfAborted, waitForReport } from '../helpers'
import type { FlowDefinition } from '../types'

/**
 * e-NPS — colunas: nome_tribo, mes_ano_competencia, total
 *
 * TODO: implementar a coleta. A página já chega autenticada e aberta na URL
 * configurada. Sugestões: setDateRangeSlicer(), selectSlicerOption(), openReportPage(),
 * exportVisualData(), typeInSlicerSearch(), toMesAno(), parseNumeroBR().
 * Campos digitáveis: use sempre human.type(locator, texto) — nunca locator.fill().
 */
export const eNps: FlowDefinition = {
  id: 'e-nps',
  async collect({ page, periodo, signal, progress, log, copilot }) {
    // Período escolhido no card. Ex. em 08/10/2026:
    //   Mês anterior → 01/09/2026 a 30/09/2026 | Mês atual → 01/10/2026 a 31/10/2026
    const dataInicial = periodo.dataInicial // DD/MM/AAAA — primeiro dia do mês
    const dataFinal = periodo.dataFinal // DD/MM/AAAA — último dia do mês (28, 29, 30 ou 31)
    const competencia = periodo.mesAno // MM/AAAA — valor da coluna mes_ano_competencia

    progress(40, 'Aguardando o relatório carregar…')
    await waitForReport(page).catch(() => log('Visuais do relatório não detectados.', 'warn'))
    throwIfAborted(signal)

    // TODO: aplicar o período no relatório, ex.:
    // await setDateRangeSlicer(page, 'Data', dataInicial, dataFinal)
    progress(60, `Período: ${dataInicial} a ${dataFinal}`)

    const rows: IndicatorRow[] = []
    // Exemplo: rows.push({ nome_tribo: 'Tribo X', mes_ano_competencia: competencia, valor: 98.5 })
    //
    // Alternativa com o GitHub Copilot — tira print do visual e devolve as linhas:
    // const rows = await copilot.screenshotToRows({
    //   target: page.locator('visual-container').filter({ hasText: 'Título do visual' }),
    //   instructions: 'Leia a tabela: uma linha por tribo; a coluna "Total" é o valor.'
    // })

    progress(90, 'Coleta ainda não implementada — gerando CSV vazio.')
    return rows
  }
}
