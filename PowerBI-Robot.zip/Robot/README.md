# PowerBI Robot

Extrator de indicadores de dashboards Power BI (Electron + React + TypeScript + Playwright, usando o Edge ou o Chrome instalado).

## Comandos

| Comando | O que faz |
| --- | --- |
| `npm install` | Instala as dependências |
| `npm run dev` | Abre o app em modo desenvolvimento |
| `npm run typecheck` | Verifica os tipos |
| `npm run build` | Compila o app em `out/` |
| `npm run dist:win` | Windows 11 x64: `dist/PowerBI Robot-Portable-x.y.z.exe` (portátil, sem instalação) |
| `npm run dist:dir` | Versão Windows descompactada em `dist/win-unpacked/` (para inspeção) |

O executável não é assinado: o SmartScreen avisa na primeira execução ("Mais informações → Executar assim mesmo").

## Electron sem download (rede corporativa)

O projeto **não baixa o Electron** no `npm install`/`npm ci`: o download está bloqueado em `allowScripts` no `package.json`. Use uma release baixada manualmente:

1. Baixe `electron-v33.2.1-win32-x64.zip` em <https://github.com/electron/electron/releases/tag/v33.2.1> (a versão precisa ser a mesma do `package.json`).
2. Descompacte numa pasta, ex.: `C:\electron\electron-v33.2.1-win32-x64` (deve conter `electron.exe`).
3. Ajuste o caminho no arquivo `electron.local.json`, na raiz do projeto (use `/` ou `\\` no Windows):
   ```json
   { "path": "C:/electron/electron-v33.2.1-win32-x64" }
   ```
   Alternativa: variável de ambiente `ELECTRON_DIST_PATH` com o mesmo caminho.

`npm run dev`, `npm run build` e `npm run dist:win` passam por `scripts/electron-local.mjs`, que usa esse caminho, confere a versão da release e avisa se algo estiver errado. Se a pasta indicada não existir na máquina mas o Electron estiver em `node_modules` (instalação sem restrição de rede), usa esse.

Com npm anterior ao 11 (que ignora `allowScripts`), defina `ELECTRON_SKIP_BINARY_DOWNLOAD=1` antes de instalar: `set ELECTRON_SKIP_BINARY_DOWNLOAD=1` (cmd) ou `$env:ELECTRON_SKIP_BINARY_DOWNLOAD=1` (PowerShell).

O `npm run dist:win` ainda baixa do GitHub, uma única vez, as ferramentas de empacotamento do electron-builder (NSIS), guardadas em `%LOCALAPPDATA%\electron-builder\Cache`. Se a rede bloquear, copie essa pasta de outra máquina ou use `ELECTRON_BUILDER_BINARIES_MIRROR` apontando para um espelho interno.

## Tela

- **Topo**: status da sessão (**Verificando sessão…**, **Autenticado** ou **Não autenticado**), botão **Entrar** (quando não autenticado), abrir a pasta dos CSVs, **Configurações** e **Sair** (encerra a sessão salva, após confirmação).
- **Card de cada fluxo**: URL do dashboard, filtro **Mês anterior / Mês atual** com o intervalo de datas, barra de progresso, ▶/■ para iniciar ou parar, download do CSV e logs da execução.
- **Configurações**: pasta de destino dos CSVs, separador do CSV (`;` ou `,`), mostrar o navegador durante a coleta, iniciar o navegador maximizado e navegador usado (**Microsoft Edge** ou **Google Chrome** instalado).

## Como funciona

- **Login**: o app não guarda e-mail nem senha. Clique em **Entrar**: uma janela do navegador configurado abre no Power BI, você digita e-mail e senha e aprova o MFA. Quando o Power BI carrega, a sessão é salva em `%APPDATA%/PowerBI Robot/session/storage-state.json` e o status muda para **Autenticado**.
- **Validação**: a sessão é verificada ao abrir o app, a cada 30 minutos e no início de cada fluxo. Se expirou, o status muda para **Não autenticado** e o fluxo para com a mensagem para clicar em Entrar.
- **Navegador**: o app não baixa navegador; usa o **Microsoft Edge** (padrão no Windows, já vem no Windows 11) ou o **Google Chrome** instalado, conforme as configurações. Se o escolhido não estiver instalado, a coleta/login mostra um erro pedindo para instalar ou trocar.
- **CSV**: exatamente um arquivo por fluxo, `<pasta configurada>/<fluxo>.csv` (ex.: `bacen.csv`), com colunas `nome_tribo`, `mes_ano_competencia` e a coluna de valor do fluxo. Sobrescrito a cada coleta bem-sucedida (gravação atômica). Se a coleta falhar ou for interrompida, o CSV anterior é mantido; se ainda não existir, é criado só com o cabeçalho.
- **Filtro de período**: todos os cards têm o filtro **Mês anterior / Mês atual** (padrão: mês anterior), salvo por fluxo, com o intervalo exibido no card. O coletor recebe `periodo` com `dataInicial` e `dataFinal` (DD/MM/AAAA, do dia 01 ao último dia real do mês — 28, 29, 30 ou 31), `inicio`/`fim` (`Date`), `mes`, `ano` e `mesAno` (MM/AAAA). Ex. em 08/10/2026: mês anterior = 01/09/2026 a 30/09/2026; mês atual = 01/10/2026 a 31/10/2026.
- **Digitação humana**: todo campo digitável dos fluxos é preenchido tecla a tecla com ritmo irregular (`src/main/human.ts`). `locator.fill()` e `page.fill()` são redirecionados automaticamente para essa digitação.

## Implementando um fluxo

Cada fluxo tem um coletor em `src/main/flows/coletores/<fluxo>.ts`. A função `collect` recebe a página já autenticada e aberta na URL do fluxo e retorna as linhas:

```ts
async collect({ page, periodo, signal, progress, log, human }) {
  const dataInicial = periodo.dataInicial // ex.: 01/09/2026
  const dataFinal = periodo.dataFinal // ex.: 30/09/2026
  const competencia = periodo.mesAno // ex.: 09/2026

  await waitForReport(page)
  await setDateRangeSlicer(page, 'Data', dataInicial, dataFinal)
  // … navegar nos visuais, ler valores …
  return [{ nome_tribo: 'Tribo X', mes_ano_competencia: competencia, valor: 98.5 }]
}
```

Para digitar use `human.type(locator, texto)`; para clicar, `human.click(locator)`.

Funções auxiliares em `src/main/flows/helpers.ts`: `waitForReport`, `openReportPage`, `exportVisualData`, `setDateRangeSlicer`, `selectSlicerOption`, `typeInSlicerSearch`, `toMesAno`, `parseNumeroBR`, `throwIfAborted`.
Nome e coluna de valor de cada fluxo ficam em `src/shared/flows.ts`; o cálculo do período fica em `src/shared/period.ts`.
Regras detalhadas para quem for desenvolver (inclusive com o GitHub Copilot): [.github/copilot-instructions.md](.github/copilot-instructions.md).
