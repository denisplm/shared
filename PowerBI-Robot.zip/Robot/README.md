# PowerBI Robot

Extrator de indicadores de dashboards Power BI (Electron + React + TypeScript + Playwright, usando o Edge ou o Chrome instalado).

## Comandos

| Comando | O que faz |
| --- | --- |
| `npm install` | Instala as dependências |
| `npm run dev` | Abre o app em modo desenvolvimento |
| `npm run typecheck` | Verifica os tipos |
| `npm run build` | Compila o app em `out/` |
| `npm run dist:win` | Windows 11 x64: instalador `dist/PowerBI Robot-Setup-x.y.z.exe` e `dist/PowerBI Robot-x.y.z-win-x64.zip` |
| `npm run icons` | Regera `build/icon.png` e `build/icon.ico` a partir de `build/icon.svg` (só ao mudar o desenho) |
| `npm run dist:dir` | Versão Windows descompactada em `dist/win-unpacked/` (para inspeção) |

**Instalador** (`PowerBI Robot-Setup-x.y.z.exe`): instala só para o usuário atual, **sem pedir administrador**. Permite escolher a pasta — se a política da empresa bloquear programas em pastas do usuário, escolha uma pasta liberada (ex.: `C:\Projetos\PowerBI Robot`). Cria atalhos na Área de Trabalho e no Menu Iniciar. Configurações e sessão (`%APPDATA%\PowerBI Robot`) são mantidas ao desinstalar ou atualizar.

**Alternativa sem instalação** (`PowerBI Robot-x.y.z-win-x64.zip`): descompacte numa pasta liberada e abra `PowerBI Robot.exe`. Use se o instalador for bloqueado. Não há versão `.exe` portátil: ela roda a partir do `%TEMP%`, bloqueado na rede corporativa.

**Ícone**: o desenho fica em `build/icon.svg`; `build/icon.ico` é usado no instalador, nos atalhos e no `PowerBI Robot.exe` (gravado por `scripts/after-pack.cjs` com a biblioteca `resedit`, sem baixar o `rcedit` do GitHub) e o SVG também é o logo do topo da tela.

Os executáveis não são assinados: o SmartScreen pode avisar na primeira execução ("Mais informações → Executar assim mesmo").

## Sem downloads (rede corporativa)

O projeto não baixa nada do GitHub: o Electron e o NSIS (usado para gerar o instalador) são baixados manualmente e indicados no arquivo `electron.local.json`, na raiz do projeto. O download automático do Electron no `npm install`/`npm ci` está bloqueado em `allowScripts` no `package.json`.

1. Baixe os três arquivos (as versões precisam ser exatamente estas):
   - `electron-v33.2.1-win32-x64.zip` — <https://github.com/electron/electron/releases/tag/v33.2.1>
   - `nsis-3.0.4.1.7z` — <https://github.com/electron-userland/electron-builder-binaries/releases/tag/nsis-3.0.4.1>
   - `nsis-resources-3.4.1.7z` — <https://github.com/electron-userland/electron-builder-binaries/releases/tag/nsis-resources-3.4.1>
2. Descompacte cada um numa pasta com o mesmo nome dentro de `C:\electron` (o Windows 11 abre `.7z` pelo Explorador de Arquivos):
   ```
   C:\electron\
   ├── electron-v33.2.1-win32-x64\   (contém electron.exe)
   ├── nsis-3.0.4.1\                 (contém makensis.exe)
   └── nsis-resources-3.4.1\         (contém a pasta plugins)
   ```
   Se a descompactação criar uma subpasta a mais (ex.: `nsis-3.0.4.1\nsis-3.0.4.1\`), tudo bem: ela é encontrada automaticamente.
3. Confira os caminhos em `electron.local.json` (use `/` ou `\\` no Windows):
   ```json
   {
     "path": "C:/electron/electron-v33.2.1-win32-x64",
     "nsisPath": "C:/electron/nsis-3.0.4.1",
     "nsisResourcesPath": "C:/electron/nsis-resources-3.4.1"
   }
   ```
   O `path` também pode vir da variável de ambiente `ELECTRON_DIST_PATH`.

`npm run dev`, `npm run build` e `npm run dist:win` passam por `scripts/electron-local.mjs`, que usa esses caminhos, confere a versão do Electron e explica o que corrigir se algo estiver errado. Se a pasta do Electron não existir na máquina mas ele estiver em `node_modules` (instalação sem restrição de rede), usa esse.

Com npm anterior ao 11 (que ignora `allowScripts`), defina `ELECTRON_SKIP_BINARY_DOWNLOAD=1` antes de instalar: `set ELECTRON_SKIP_BINARY_DOWNLOAD=1` (cmd) ou `$env:ELECTRON_SKIP_BINARY_DOWNLOAD=1` (PowerShell).

## Tela

- **Topo**: status da sessão (**Verificando sessão…**, **Autenticado** ou **Não autenticado**), botão **Entrar** (quando não autenticado), abrir a pasta dos CSVs, **Configurações** e **Sair** (encerra a sessão salva, após confirmação).
- **Card de cada fluxo**: URL do dashboard, filtro **Mês anterior / Mês atual** com o intervalo de datas, barra de progresso, ▶/■ para iniciar ou parar, download do CSV e logs da execução.
- **Configurações**: pasta de destino dos CSVs, separador do CSV (`;` ou `,`), mostrar o navegador durante a coleta, iniciar o navegador maximizado, navegador usado (**Microsoft Edge** ou **Google Chrome** instalado) e **GitHub Copilot** (status da conexão, botão **Entrar no Copilot** e modelo usado para ler imagens).

## Como funciona

- **Login**: o app não guarda e-mail nem senha. Clique em **Entrar**: uma janela do navegador configurado abre no Power BI, você digita e-mail e senha e aprova o MFA. Quando o Power BI carrega, a sessão é salva em `%APPDATA%/PowerBI Robot/session/storage-state.json` e o status muda para **Autenticado**.
- **Validação**: a sessão é verificada ao abrir o app, a cada 30 minutos e no início de cada fluxo. Se expirou, o status muda para **Não autenticado** e o fluxo para com a mensagem para clicar em Entrar.
- **Navegador**: o app não baixa navegador; usa o **Microsoft Edge** (padrão, já vem no Windows 11) ou o **Google Chrome** instalado, conforme as configurações. Se o escolhido não estiver instalado, a coleta/login mostra um erro pedindo para instalar ou trocar. Se o navegador fechar logo ao iniciar (comum na primeira abertura), o app tenta de novo automaticamente (até 3 vezes). A autenticação (**Entrar**) sempre abre o navegador visível.
- **CSV**: exatamente um arquivo por fluxo, `<pasta configurada>/<fluxo>.csv` (ex.: `bacen.csv`), com colunas `nome_tribo`, `mes_ano_competencia` e a coluna de valor do fluxo. Sobrescrito a cada coleta bem-sucedida (gravação atômica). Se a coleta falhar ou for interrompida, o CSV anterior é mantido; se ainda não existir, é criado só com o cabeçalho.
- **Filtro de período**: todos os cards têm o filtro **Mês anterior / Mês atual** (padrão: mês anterior), salvo por fluxo, com o intervalo exibido no card. O coletor recebe `periodo` com `dataInicial` e `dataFinal` (DD/MM/AAAA, do dia 01 ao último dia real do mês — 28, 29, 30 ou 31), `inicio`/`fim` (`Date`), `mes`, `ano` e `mesAno` (MM/AAAA). Ex. em 08/10/2026: mês anterior = 01/09/2026 a 30/09/2026; mês atual = 01/10/2026 a 31/10/2026.
- **Digitação humana**: todo campo digitável dos fluxos é preenchido tecla a tecla com ritmo irregular (`src/main/human.ts`). `locator.fill()` e `page.fill()` são redirecionados automaticamente para essa digitação.

## GitHub Copilot (leitura de prints)

Alguns relatórios são mais fáceis de ler por imagem: o coletor tira um print do visual e o **GitHub Copilot** (licença corporativa) devolve as linhas do CSV. A integração usa o [GitHub Copilot SDK](https://github.com/github/copilot-sdk) (`@github/copilot-sdk`).

- **Conectar**: Configurações → GitHub Copilot → **Entrar no Copilot**. O navegador padrão abre a autorização do GitHub; entre com a conta da empresa. A conexão fica salva para as próximas vezes. **Verificar** atualiza o status.
- **Modelo**: escolha um modelo que aceite imagens (a lista mostra só esses) ou deixe "Padrão do Copilot".
- **No coletor**: `copilot.screenshotToRows({ target, instructions })` tira o print da página (ou do elemento `target`) e devolve as linhas; `copilot.imageToRows(caminho, instructions)` faz o mesmo com uma imagem existente. O indicador, a coluna de valor e a competência do filtro de período já vão no pedido; `instructions` explica o que ler naquele relatório.
- **Prints**: ficam em `%APPDATA%\PowerBI Robot\prints\<fluxo>\` para conferência.
- **Sem downloads do GitHub**: o runtime do Copilot vem no pacote npm `@github/copilot-sdk-win32-x64` (instalado pelo `npm ci`) e roda da pasta do app; atualização automática desligada. Gere o instalador **no Windows**, para que o runtime do Windows seja incluído.
- **Atenção**: os prints dos relatórios são enviados ao GitHub Copilot da empresa. Use apenas conforme a política de uso de IA da empresa.

## Implementando um fluxo

Cada fluxo tem um coletor em `src/main/flows/coletores/<fluxo>.ts`. A função `collect` recebe a página já autenticada e aberta na URL do fluxo e retorna as linhas:

```ts
async collect({ page, periodo, signal, progress, log, human }) {
  const dataInicial = periodo.dataInicial // ex.: 01/09/2026
  const dataFinal = periodo.dataFinal // ex.: 30/09/2026
  const competencia = periodo.mesAno // ex.: 09/2026

  await waitForReport(page)
  await setDateRangeSlicer(page, 'Data', dataInicial, dataFinal)
  // … navegar nos visuais, ler valores …
  return [{ nome_tribo: 'Tribo X', mes_ano_competencia: competencia, valor: 98.5 }]
}
```

Para digitar use `human.type(locator, texto)`; para clicar, `human.click(locator)`. Para ler um visual por imagem com o Copilot: `const rows = await copilot.screenshotToRows({ target, instructions })`.

Funções auxiliares em `src/main/flows/helpers.ts`: `waitForReport`, `openReportPage`, `exportVisualData`, `setDateRangeSlicer`, `selectSlicerOption`, `typeInSlicerSearch`, `toMesAno`, `parseNumeroBR`, `throwIfAborted`.
Nome e coluna de valor de cada fluxo ficam em `src/shared/flows.ts`; o cálculo do período fica em `src/shared/period.ts`.
Regras detalhadas para quem for desenvolver (inclusive com o GitHub Copilot): [.github/copilot-instructions.md](.github/copilot-instructions.md).
